/*----------------------------------------------------------------------------
 * Name:    Blinky.c
 * Purpose: LED Flasher
 * Note(s): __USE_LCD   - enable Output on LCD, uncomment #define in code to use
 *  				for demo (NOT for analysis purposes)
 *----------------------------------------------------------------------------
 * Copyright (c) 2008-2011 Keil - An ARM Company.
 * Name: Anita Tino
 *----------------------------------------------------------------------------*/

#include <stdio.h>
#include "LPC17xx.H"                       
#include "GLCD.h"
#include "LED.h"
#include "ADC.h"
#include "KBD.h"
#include "KBD.c"
#include "finalballoon.c"
#include "pikachu.c"
#include "usb.h"
#include "usbcfg.h"
#include "usbhw.h"
#include "usbcore.h"
#include "usbaudio.h"

#define __FI        1                      /* Font index 16x24               */
#define __USE_LCD   0										/* Uncomment to use the LCD */


//ITM Stimulus Port definitions for printf //////////////////
#define ITM_Port8(n)    (*((volatile unsigned char *)(0xE0000000+4*n)))
#define ITM_Port16(n)   (*((volatile unsigned short*)(0xE0000000+4*n)))
#define ITM_Port32(n)   (*((volatile unsigned long *)(0xE0000000+4*n)))

#define DEMCR           (*((volatile unsigned long *)(0xE000EDFC)))
#define TRCENA          0x01000000

void Game();
void photo_update();
void Photos();
void Audio();
void Game();
void mainMenu();


/////////////////////////////////////////////////////////

uint32_t joy_num = 0;
//Use to trace the pot values in Debug
uint16_t ADC_Dbg;
int counter =0;
int photo_cnt =0;
/* Import external variables from IRQ.c file                                  */
extern uint8_t  clock_ms;
int mm_pos[] = {3,5,7};


void delay()
{
	int i ;
	for(i= 0; i< 2000000; i++){}
}

void update_LCD()
{
#ifdef __USE_LCD
		if (counter == 0)
		{
			GLCD_SetBackColor(Red);
			GLCD_DisplayString(4, 0, __FI, "       Audio        ");
			GLCD_SetBackColor(White);
			GLCD_DisplayString(6, 0, __FI, "       Gallery      ");
			GLCD_DisplayString(8, 0, __FI, "       Game         ");
		}
		else if (counter == 1)
		{
			GLCD_SetBackColor(Red);
			GLCD_DisplayString(6, 0, __FI, "       Gallery      ");
			GLCD_SetBackColor(White);
			GLCD_DisplayString(4, 0, __FI, "       Audio        ");			
			GLCD_DisplayString(8, 0, __FI, "       Game         ");
		}
		else if (counter == 2)
		{
			GLCD_SetBackColor(Red);		
			GLCD_DisplayString(8, 0, __FI, "       Game         ");		
			GLCD_SetBackColor(White);
			GLCD_DisplayString(4, 0, __FI, "       Audio        ");	
			GLCD_DisplayString(6, 0, __FI, "       Gallery      ");	
		}
	#endif
}
void mm_func()
{

	while (1) {                                /* Loop forever                  */
		
		int joy_num = get_button();
						
				if(joy_num == KBD_DOWN){
					LED_On(0);
					counter++;
					delay();
					LED_Off(0);
				}
				else if(joy_num == KBD_UP){
					LED_On(3);
					counter--;					
					delay();
					LED_Off(3);
				} 
				else if(joy_num == KBD_SELECT){
						LED_On(7);
						LED_Off(7);
						if (counter == 0)
						{
							Audio();
							break;
						}
						else if (counter == 1)
						{
							Photos();
							break;
						}
						else if (counter == 2)
						{
							Game();
							break;
						}
				}
					update_LCD();
  }
}
void mainMenu()
{

	#ifdef __USE_LCD
  GLCD_Clear(White);                         /* Clear graphical LCD display   */
  GLCD_SetBackColor(Navy);
  GLCD_SetTextColor(Yellow);
  GLCD_DisplayString(0, 0, __FI, "     MAIN MENU        ");
	GLCD_SetTextColor(LightGrey);
	GLCD_DisplayString(1, 0, __FI, "   SCROLL UP/DOWN     ");
	GLCD_SetTextColor(Navy);
	GLCD_SetBackColor(White);
	#endif
	GLCD_DisplayString(4, 0, __FI, "       Audio        ");
  GLCD_DisplayString(6, 0, __FI, "       Gallery      ");
	GLCD_DisplayString(8, 0, __FI, "       Game         ");

	mm_func();
}

void photo_update()
{
	
	#include "finalballoon.c"
	#include "pikachu.c"
	#include "fireworks2.c"
	
	if (photo_cnt > 3){ photo_cnt = 0;}
	else if(photo_cnt <0) {photo_cnt = 3;}
	else if (photo_cnt == 0) //update LCD
	{
			//GLCD_Clear(White);                         /* Clear graphical LCD display   */
			//GLCD_SetBackColor(Navy);
			//GLCD_SetTextColor(Yellow);
			//GLCD_DisplayString(0, 0, __FI, "     PHOTO GALLERY        ");
			//GLCD_SetTextColor(LightGrey);
			//GLCD_DisplayString(1, 0, __FI, "    SCROLL UP OR DOWN     ");
			//GLCD_DisplayString(2, 0, __FI, "      EXIT == LEFT        ");
	}
	else if(photo_cnt == 1)
	{
		GLCD_Bitmap (50,   80, 240,  135, (unsigned char *)GIMP_IMAGE_pixel_data);
		//delay();
	}
	else if(photo_cnt == 2)
	{
		GLCD_Bitmap (50, 80, 221,  140, (unsigned char *)PICKACHU_pixel_data);
	}
	else if (photo_cnt == 3)
	{
		GLCD_Bitmap (70, 100, 100,  67, (unsigned char *) FIREWORK_pixel_data);

	}
}
void Photos()
{	
	#ifdef __USE_LCD
			GLCD_Clear(White);                         /* Clear graphical LCD display   */
			GLCD_SetBackColor(Navy);
			GLCD_SetTextColor(Yellow);
			GLCD_DisplayString(0, 0, __FI, "     PHOTO GALLERY        ");
			GLCD_SetTextColor(LightGrey);
			GLCD_DisplayString(1, 0, __FI, "    SCROLL UP OR DOWN     ");
			GLCD_DisplayString(2, 0, __FI, "      EXIT == LEFT        ");
		#endif
	while(1)
	{
		int joy_num = get_button();
		if (joy_num == KBD_UP)
		{
			photo_cnt++;
			delay();
		}
		else if(joy_num == KBD_DOWN)
		{
			photo_cnt--;
			delay();
		}
		else if(joy_num == KBD_LEFT)
		{
			mainMenu();
		}
		photo_update();
	}
}
extern  void SystemClockUpdate(void);
extern uint32_t SystemFrequency;  
uint8_t  Mute;                                 /* Mute State */
uint32_t Volume;                               /* Volume Level */

#if USB_DMA
uint32_t *InfoBuf = (uint32_t *)(DMA_BUF_ADR);
short *DataBuf = (short *)(DMA_BUF_ADR + 4*P_C);
#else
uint32_t InfoBuf[P_C];
short DataBuf[B_S];                         /* Data Buffer */
#endif

uint16_t  DataOut;                              /* Data Out Index */
uint16_t  DataIn;                               /* Data In Index */

uint8_t   DataRun;                              /* Data Stream Run State */
uint16_t  PotVal;                               /* Potenciometer Value */
uint32_t  VUM;                                  /* VU Meter */
uint32_t  Tick;                                 /* Time Tick */


/*
 * Get Potenciometer Value
 */

void get_potval (void) {
  uint32_t val;

  LPC_ADC->CR |= 0x01000000;              /* Start A/D Conversion */
  do {
    val = LPC_ADC->GDR;                   /* Read A/D Data Register */
  } while ((val & 0x80000000) == 0);      /* Wait for end of A/D Conversion */
  LPC_ADC->CR &= ~0x01000000;             /* Stop A/D Conversion */
  PotVal = ((val >> 8) & 0xF8) +          /* Extract Potenciometer Value */
           ((val >> 7) & 0x08);
}


/*
 * Timer Counter 0 Interrupt Service Routine
 *   executed each 31.25us (32kHz frequency)
 */

void TIMER0_IRQHandler(void) 
{
  long  val;
  uint32_t cnt;

  if (DataRun) {                            /* Data Stream is running */
    val = DataBuf[DataOut];                 /* Get Audio Sample */
    cnt = (DataIn - DataOut) & (B_S - 1);   /* Buffer Data Count */
    if (cnt == (B_S - P_C*P_S)) {           /* Too much Data in Buffer */
      DataOut++;                            /* Skip one Sample */
    }
    if (cnt > (P_C*P_S)) {                  /* Still enough Data in Buffer */
      DataOut++;                            /* Update Data Out Index */
    }
    DataOut &= B_S - 1;                     /* Adjust Buffer Out Index */
    if (val < 0) VUM -= val;                /* Accumulate Neg Value */
    else         VUM += val;                /* Accumulate Pos Value */
    val  *= Volume;                         /* Apply Volume Level */
    val >>= 16;                             /* Adjust Value */
    val  += 0x8000;                         /* Add Bias */
    val  &= 0xFFFF;                         /* Mask Value */
  } else {
    val = 0x8000;                           /* DAC Middle Point */
  }

  if (Mute) {
    val = 0x8000;                           /* DAC Middle Point */
  }

  LPC_DAC->CR = val & 0xFFC0;             /* Set Speaker Output */

  if ((Tick++ & 0x03FF) == 0) {             /* On every 1024th Tick */
    get_potval();                           /* Get Potenciometer Value */
    if (VolCur == 0x8000) {                 /* Check for Minimum Level */
      Volume = 0;                           /* No Sound */
    } else {
      Volume = VolCur * PotVal;             /* Chained Volume Level */
    }
    val = VUM >> 20;                        /* Scale Accumulated Value */
    VUM = 0;                                /* Clear VUM */
    if (val > 7) val = 7;                   /* Limit Value */
  }

  LPC_TIM0->IR = 1;                         /* Clear Interrupt Flag */
}

void Audio()
{
	#ifdef __USE_LCD
			GLCD_Clear(White);                         /* Clear graphical LCD display   */
			GLCD_SetBackColor(Navy);
			GLCD_SetTextColor(Yellow);
			GLCD_DisplayString(0, 0, __FI, "   AUDIO STREAMING      ");
			GLCD_SetTextColor(LightGrey);
			GLCD_DisplayString(1, 0, __FI, "    EXIT == LEFT        ");
		#endif
		if (get_button() == KBD_LEFT){mainMenu();}
		
		 volatile uint32_t pclkdiv, pclk;

  /* SystemClockUpdate() updates the SystemFrequency variable */
  SystemClockUpdate();

  LPC_PINCON->PINSEL1 &=~((0x03<<18)|(0x03<<20));  
  /* P0.25, A0.0, function 01, P0.26 AOUT, function 10 */
  LPC_PINCON->PINSEL1 |= ((0x01<<18)|(0x02<<20));

  /* Enable CLOCK into ADC controller */
  LPC_SC->PCONP |= (1 << 12);

  LPC_ADC->CR = 0x00200E04;		/* ADC: 10-bit AIN2 @ 4MHz */
  LPC_DAC->CR = 0x00008000;		/* DAC Output set to Middle Point */

  /* By default, the PCLKSELx value is zero, thus, the PCLK for
  all the peripherals is 1/4 of the SystemFrequency. */
  /* Bit 2~3 is for TIMER0 */
  pclkdiv = (LPC_SC->PCLKSEL0 >> 2) & 0x03;
  switch ( pclkdiv )
  {
	case 0x00:
	default:
	  pclk = SystemFrequency/4;
	break;
	case 0x01:
	  pclk = SystemFrequency;
	break; 
	case 0x02:
	  pclk = SystemFrequency/2;
	break; 
	case 0x03:
	  pclk = SystemFrequency/8;
	break;
  }

  LPC_TIM0->MR0 = pclk/DATA_FREQ - 1;	/* TC0 Match Value 0 */
  LPC_TIM0->MCR = 3;					/* TCO Interrupt and Reset on MR0 */
  LPC_TIM0->TCR = 1;					/* TC0 Enable */
  NVIC_EnableIRQ(TIMER0_IRQn);

  USB_Init();				/* USB Initialization */
  //USB_Connect(TRUE);		/* USB Connect */

  /********* The main Function is an endless loop ***********/ 
  while( 1 ); 
}
void Game()
{
	
}

/*----------------------------------------------------------------------------
  Main Program
 *----------------------------------------------------------------------------*/
int main (void) {
  LED_Init();                                /* LED Initialization            */
  ADC_Init();                                /* ADC Initialization            */
	KBD_Init();																	/*KBD Initialization						*/
	GLCD_Init();                               /* Initialize graphical LCD (if enabled */
	mainMenu();
	
}