/*----------------------------------------------------------------------------
 * Name:    Blinky.c
 * Purpose: LED Flasher
 * Note(s): __USE_LCD   - enable Output on LCD, uncomment #define in code to use
 *  				for demo (NOT for analysis purposes)
 *----------------------------------------------------------------------------
 * Copyright (c) 2008-2011 Keil - An ARM Company.
 * Name: Anita Tino
 *----------------------------------------------------------------------------*/

#include <stdio.h>
#include "LPC17xx.H"                       
#include "GLCD.h"
#include "type.h"
#include "LED.h"
#include "ADC.h"
#include "KBD.h"
#include "KBD.c"
#include "redtest3.c"
#include "yellowtest.c"

#define __FI        1                      /* Font index 16x24               */
#define __USE_LCD   0										/* Uncomment to use the LCD */


void Game();
void photo_update();
void Photos();
void Audio();
void Game();
void mainMenu();


/////////////////////////////////////////////////////////

char text[10];
uint32_t joy_num = 0;
//Use to trace the pot values in Debug
uint16_t ADC_Dbg;
int counter =0;
int photo_cnt = 0;
int x_counter = 1;
int y_counter[6] = {6,6,6,6,6,6};
/* Import external variables from IRQ.c file                                  */
extern uint8_t  clock_ms;
int mm_pos[] = {3,5,7};
extern void stream(void);
int x_pos[7] = {25,65,105,142,180,218,260}; 
int y_pos[6] = {35,68,103,138,173,204}; 
char board[sizeof(x_pos)*sizeof(y_pos)];
int player, win;

void delay()
{
	int i ;
	for(i= 0; i< 2000000; i++){}
}
void delay2(int time)
{
	int i ;
	for(i= 0; i< time; i++){}
}
void update_LCD()
{
#ifdef __USE_LCD
		if (counter == 0)
		{
			GLCD_SetBackColor(Red);
			GLCD_DisplayString(4, 0, __FI, "       Audio        ");
			GLCD_SetBackColor(White);
			GLCD_DisplayString(6, 0, __FI, "       Gallery      ");
			GLCD_DisplayString(8, 0, __FI, "       Game         ");
		}
		else if (counter == 1)
		{
			GLCD_SetBackColor(Red);
			GLCD_DisplayString(6, 0, __FI, "       Gallery      ");
			GLCD_SetBackColor(White);
			GLCD_DisplayString(4, 0, __FI, "       Audio        ");			
			GLCD_DisplayString(8, 0, __FI, "       Game         ");
		}
		else if (counter == 2)
		{
			GLCD_SetBackColor(Red);		
			GLCD_DisplayString(8, 0, __FI, "       Game         ");		
			GLCD_SetBackColor(White);
			GLCD_DisplayString(4, 0, __FI, "       Audio        ");	
			GLCD_DisplayString(6, 0, __FI, "       Gallery      ");	
		}
	#endif
}
void mm_func()
{

	while (1) {                                /* Loop forever                  */
		
		int joy_num = get_button();
						
				if(joy_num == KBD_DOWN){
					LED_On(0);
					counter++;
					delay();
					LED_Off(0);
				}
				else if(joy_num == KBD_UP){
					LED_On(3);
					counter--;					
					delay();
					LED_Off(3);
				} 
				else if(joy_num == KBD_SELECT){
						LED_On(7);
						LED_Off(7);
						if (counter == 0)
						{
							Audio();
							break;
						}
						else if (counter == 1)
						{
							Photos();
							break;
						}
						else if (counter == 2)
						{
							Game();
							break;
						}
				}
					update_LCD();
  }
}
void mainMenu()
{

	#ifdef __USE_LCD
  GLCD_Clear(White);                         /* Clear graphical LCD display   */
  GLCD_SetBackColor(Navy);
  GLCD_SetTextColor(Yellow);
  GLCD_DisplayString(0, 0, __FI, "     MAIN MENU        ");
	GLCD_SetTextColor(LightGrey);
	GLCD_DisplayString(1, 0, __FI, "   SCROLL UP/DOWN     ");
	GLCD_SetTextColor(Navy);
	GLCD_SetBackColor(White);
	#endif
	GLCD_DisplayString(4, 0, __FI, "       Audio        ");
  GLCD_DisplayString(6, 0, __FI, "       Gallery      ");
	GLCD_DisplayString(8, 0, __FI, "       Game         ");

	mm_func();
}

void photo_update()
{
	
//	#include "finalballoon.c"
//	#include "pikachu.c"
//	#include "sunset.c"
//	
//	if (photo_cnt > 3){ photo_cnt = 1;}
//	else if(photo_cnt <1) {photo_cnt = 3;}
//	else if(photo_cnt == 1)
//	{
//		GLCD_Bitmap (20,   80, 240,  135, (unsigned char *)GIMP_IMAGE_pixel_data);
//	}
//	else if(photo_cnt == 2)
//	{
//		GLCD_Bitmap (50, 80, 221,  140, (unsigned char *)PICKACHU_pixel_data);
//	}
//	else if (photo_cnt == 3)
//	{
//		GLCD_Bitmap (50, 80, 200,  133, (unsigned char *) SUNSET_pixel_data);
//	}
}
void Photos()
{	
	#ifdef __USE_LCD
			GLCD_Clear(White);                         /* Clear graphical LCD display   */
			GLCD_SetBackColor(Navy);
			GLCD_SetTextColor(Yellow);
			GLCD_DisplayString(0, 0, __FI, "    PHOTO GALLERY          ");
			GLCD_SetTextColor(LightGrey);
			GLCD_DisplayString(1, 0, __FI, "  SCROLL UP OR DOWN        ");
			GLCD_DisplayString(2, 0, __FI, "     EXIT == LEFT          ");
		#endif
	while(1)
	{
		int joy_num = get_button();
		if (joy_num == KBD_UP)
		{
			photo_cnt++;
			delay();
		}
		else if(joy_num == KBD_DOWN)
		{
			photo_cnt--;
			delay();
		}
		else if(joy_num == KBD_LEFT)
		{
			mainMenu();
		}
		photo_update();
	}
}

void Audio()
{

		GLCD_Clear(White);                         /* Clear graphical LCD display   */
		GLCD_SetBackColor(Navy);
		GLCD_SetTextColor(Yellow);
		GLCD_DisplayString(0, 0, __FI, "   AUDIO STREAMING      ");
		GLCD_SetTextColor(LightGrey);
		GLCD_DisplayString(1, 0, __FI, "    EXIT = LEFT        ");
		stream();
}

int checkFour(char *board, int a, int b, int c, int d){
    return (board[a] == board[b] && board[b] == board[c] && board[c] == board[d] && board[a] != ' ');

}
int horizontalCheck(char *board){
    int row, col, idx;
    const int WIDTH = 1;

    for(row = 0; row < sizeof(x_pos); row++){
       for(col = 0; col < sizeof(y_pos) - 3; col++){
          idx = sizeof(y_pos) * row + col;
          if(checkFour(board, idx, idx + WIDTH, idx + WIDTH * 2, idx + WIDTH * 3)){
             return 1;
          }
       }
    }
    return 0;

}
int verticalCheck(char *board){
    int row, col, idx;
    const int HEIGHT = 7;

    for(row = 0; row < sizeof(x_pos) - 3; row++){
       for(col = 0; col < sizeof(y_pos); col++){
          idx = sizeof(y_pos) * row + col;
          if(checkFour(board, idx, idx + HEIGHT, idx + HEIGHT * 2, idx + HEIGHT * 3)){
              return 1;
          }
       }
    }
    return 0;

}
int diagonalCheck(char *board){
   int row, col, idx, count = 0;
   const int DIAG_RGT = 6, DIAG_LFT = 8;

   for(row = 0; row < sizeof(x_pos) - 3; row++){
      for(col = 0; col < sizeof(y_pos); col++){
         idx = sizeof(y_pos) * row + col;
         if((count <= 3 && checkFour(board, idx, idx + DIAG_LFT, idx + DIAG_LFT * 2, idx + DIAG_LFT * 3)) || (count >= 3 && checkFour(board, idx, idx + DIAG_RGT, idx + DIAG_RGT * 2, idx + DIAG_RGT * 3))){
            return 1;
         }
         count++;
      }
      count = 0;
   }
   return 0;

}
int checkWin(char *board){
    return (horizontalCheck(board) || verticalCheck(board) || diagonalCheck(board));

}
void updateYpos()
{
	char str[20];
	char colour[10];
	int i;
	for (i =0; i< sizeof(y_counter); i++)
	{
		if(x_counter == i) 
		{				
			y_counter[i-1]-=1;
			
			if (y_counter[i-1] < 0){sprintf(str,"Column full");}
			if (player == 1)
			{
				GLCD_Bitmap (x_pos[x_counter - 1], y_pos[y_counter[x_counter - 1]], 30,  30, (unsigned char *)  RED_pixel_data) ; 
				board[i] = 'X';
			}
			else 
			{
				GLCD_Bitmap (x_pos[x_counter - 1], y_pos[y_counter[x_counter - 1]], 30,  30, (unsigned char *)  YELLOW_pixel_data);
				board[i] = 'O';
			}
		}
	}
		if (i == sizeof (y_counter) && !win){GLCD_DisplayString(0, 1, __FI, "      TIE!        ");}
		else 
		{
			if (player == 1) {sprintf(colour, "RED");}
			else{sprintf(colour, "YELLOW");}
			sprintf (str, "Player %d (%c) wins!\n", player, colour);
			GLCD_DisplayString(0, 1, __FI, (unsigned char *) str);
		}
}
void updateXpos()
{

	if (x_counter > 7){ x_counter = 1;}
	else if(x_counter < 1) {x_counter = 7;}
	else if(x_counter == 1) {	GLCD_DisplayString(0, 1, __FI, "|                 ");}
	else if(x_counter == 2) {	GLCD_DisplayString(0, 1, __FI, "   |              ");}
	else if(x_counter == 3) {	GLCD_DisplayString(0, 1, __FI, "      |           ");}
	else if(x_counter == 4) {	GLCD_DisplayString(0, 1, __FI, "        |         ");}
	else if(x_counter == 5) {	GLCD_DisplayString(0, 1, __FI, "          |       ");}
	else if(x_counter == 6) {	GLCD_DisplayString(0, 1, __FI, "             |    ");}
	else if(x_counter == 7) {	GLCD_DisplayString(0, 1, __FI, "               |  ");}
}
void getMoves()
{
	GLCD_DisplayString(0, 1, __FI, "|");	
	while(1)
	{
		int joy_num = get_button();
		if (joy_num == KBD_LEFT)
		{
			x_counter--;
		}
		else if(joy_num == KBD_RIGHT)
		{
			x_counter++;	
		}
		else if(joy_num == KBD_SELECT)
		{
			 updateYpos();
				break;
		}
		updateXpos();
		delay2(5000000);		
	}
}
void playGame()
{
	int turn;
	while (win ==0)
	{
		if (turn % 2 == 0)
			{
				player = 1;
				getMoves();
			}
			else 
			{
				player = 2;
				getMoves();
			}
			turn+=1;
			win = checkWin(board);
	}
}
void Game()
{	
			#include "testBoard1.c"
			GLCD_Clear(Black);                         /* Clear graphical LCD display   */
			GLCD_SetTextColor(Yellow);
			GLCD_DisplayString(5, 0, __FI, "     CONNECT 4          ");
			delay2(9500000);
			GLCD_Clear(Black);                         
			GLCD_Bitmap (15, 30, 275,  206, (unsigned char *)  BOARD_pixel_data);		
			playGame();			
}
/*----------------------------------------------------------------------------
  Main Program
 *----------------------------------------------------------------------------*/
int main (void) {
  LED_Init();                                /* LED Initialization            */
  ADC_Init();                                /* ADC Initialization            */
	KBD_Init();																	/*KBD Initialization						*/
	GLCD_Init();                               /* Initialize graphical LCD (if enabled */
	mainMenu();
	return 0;
}