#include <stdio.h>
#include "LPC17xx.h"
#include <RTL.h>
#define LED_Bit3   (*((volatile unsigned long *)0x23380A8C))
#define LED_Bit29  (*((volatile unsigned long *)0x233806E4))
	
	
OS_TID id1, id2,id3,id4,id5;
OS_MUT mut;
char logger [10]; 
int  mem_cnt = 0, cpu_cnt = 0, app_cnt = 0, dvc_cnt = 0, user_cnt = 0;

__task void memMgnt (void);
__task void cpuMgnt (void);
__task void appMgnt (void);
__task void dvcMgnt (void);
__task void userMgnt (void);
void bitBanding();
void barrelShift();

void time_delay(int time){
	int i =0;
	while(i<time){i++;}
}

void bitBanding (){
		LED_Bit3 = 1; // turning on
		LED_Bit29 = 1; 
		time_delay(10000);
		LED_Bit3 = 0; // clearing 
		LED_Bit29 = 0;
}

void barrelShift(){
		int r1 = 1, r2 = 0, r3 = 5;
		while(r2 <= 0x1F){
			if((r1 - r2) > 0){
				r1 = r1 + 2;
				r2 = r1 + (r3*5);
				r3 = r3/2;
		}
			else{
				r2 = r2 + 1;
			}
		}

}
__task void memMgnt (void) {
	id1 = os_tsk_self(); //identify myself and create memMgnt

		mem_cnt++; //increment memory access counter
		bitBanding();
		os_tsk_pass(); //increment alongside by passing token (same priority) - cpuMgnt
		if(os_evt_wait_and(0x0004, 0xFFFF)){ 
			os_dly_wait (1); //Delay 1 tick
			os_tsk_delete_self(); //delete self
		}
}

__task void cpuMgnt(void) {

		if(cpu_cnt == 0){ 
			cpu_cnt++;
			barrelShift();
			os_tsk_pass(); //Pass back to memMgnt
		}
		os_evt_set(0x0004, id1); //finished counting. Signal to memMgnt
		os_tsk_delete_self(); //should go to idle_deamon after this
	
}

__task void appMgnt (void) {
	id3 = os_tsk_self(); //obtain my identity
		
			os_mut_wait(mut, 0xffff);
			sprintf(logger, "Start");
			os_mut_release(mut);
			os_tsk_pass(); // passing token to Device mngt
		
		if(os_evt_wait_and(0x0005, 0xFFFF)){
			app_cnt++;
			os_dly_wait (1);  //Delay 1 tick
			os_tsk_delete_self(); //delete self
		}	
}
__task void dvcMgnt (void){
			
				os_mut_wait(mut, 0xffff);
				sprintf(&logger[5], " End!");
				os_evt_set(0x0005, id3); //finished counting. Signal to AppMgnt
				dvc_cnt++;
				os_dly_wait (1);  //Delay 1 tick
				os_mut_release(mut);
				os_tsk_delete_self(); //delet self
	
}

__task void userMgnt (void){
	
		id5 = os_tsk_self(); //obtain my identity
		user_cnt++;
		os_dly_wait (1);  //Delay 1 tick
		os_tsk_delete_self(); //delet self	
}

void out(){
	os_tsk_create(memMgnt, 0x04); //create mem1 and initialize system
	os_tsk_create(cpuMgnt, 0x04);
	os_tsk_create(appMgnt, 0x02);
	os_tsk_create(dvcMgnt, 0x02);
	os_tsk_create(userMgnt,0x01);

}
int main (void) {
	SystemInit();
	out();
}
