#include <stdio.h>
#include "LPC17xx.h"
#include <RTL.h>

long cnt1 = 1, cnt2 = 2, cnt3 = 3;

__task void task1(void){
	while(1){
		cnt1+=1;
		if(cnt1 > 100)
			os_tsk_delete_self();
	}
}

__task void task2(void){
	while(1){
		cnt2++;
		if (cnt2 > 150)
			os_tsk_delete_self();
	}
}
__task void task3(void){
	while(1){
		cnt3+=2;
		if(cnt3 > 200)
		{
			os_tsk_delete_self();
		}
	}
}

int main(void){
	SystemInit();
	os_tsk_create(task3, 1);
	os_tsk_create(task1, 1);
	os_tsk_create(task2, 1);
	
	os_tsk_delete_self();

	os_sys_init(task2);
}
