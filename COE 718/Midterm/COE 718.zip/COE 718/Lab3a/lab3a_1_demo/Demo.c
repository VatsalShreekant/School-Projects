#include <stdio.h>
#include "LPC17xx.h"
#include <RTL.h>
#include "LED.h"
#include "GLCD.h"

#define __USE_LCD   0
#define __FI        1   /* Font index 16x24               */
int cnt1 = 1, cnt2 = 1, cnt3 =1;
char output[50];

void time_delay(int time){
	int i =0;
	while(i<time){i++;}
}
__task void task1(void){
	while(1){
		LED_Out(0xFF);
		GLCD_DisplayString(6,  7, __FI,  "task1  ");
		cnt1+=1;
		sprintf(output,"0x%04X",cnt1);
		time_delay(100000);
		if(cnt1 > 100)
			os_tsk_delete_self();
	}
}

__task void task2(void){
	while(1){
		LED_Out(0xFC);
		GLCD_DisplayString(6,  7, __FI,  "task2  ");
		cnt2++;
		sprintf(output,"0x%04X",cnt2);                
		time_delay(100000);
		if (cnt2 > 150)
			os_tsk_delete_self();
	}
}
__task void task3(void){
	while(1){
		LED_Out(0xF0);
		//LED_Off(7);
		GLCD_DisplayString(6,  7, __FI,  "task3  ");
		cnt3+=2;
		sprintf(output,"0x%04X",cnt3);
		time_delay(1000000);
		if(cnt3 > 200)
		{
			os_tsk_delete_self();
		}
	}
}

__task void LCD(void){
		GLCD_Init(); 
		GLCD_Clear(White);                         // Clear graphical LCD display   
		GLCD_SetBackColor(Purple);
		GLCD_SetTextColor(White);
		GLCD_DisplayString(0, 0, __FI, "    COE718 Lab3a     ");
		GLCD_DisplayString(1, 0, __FI, "    Round Robin      ");
		GLCD_DisplayString(2, 0, __FI, "    Vidhi Patel      ");
		GLCD_SetBackColor(White);
		GLCD_SetTextColor(Purple);
		os_tsk_delete_self();
}

 void out(void){
		os_tsk_create(LCD, 255);
		os_tsk_create(task1, 1);
		os_tsk_create(task2, 1);
		os_tsk_create(task3, 1);
		//os_tsk_delete_self();

}

int main(void){

		LED_Init();
		SystemInit();
		out();
		
		
}
