#include "LPC17xx.h"
#include <stdio.h>
#include "bitband.h"

//------- ITM Stimulus Port definitions for printf ------------------- //
#define ITM_Port8(n)    (*((volatile unsigned char *)(0xE0000000+4*n)))
#define ITM_Port16(n)   (*((volatile unsigned short*)(0xE0000000+4*n)))
#define ITM_Port32(n)   (*((volatile unsigned long *)(0xE0000000+4*n)))
#define DEMCR           (*((volatile unsigned long *)(0xE000EDFC)))
#define TRCENA          0x01000000

struct __FILE { int handle;  };
FILE __stdout;
FILE __stdin;

int fputc(int ch, FILE *f) {
  if (DEMCR & TRCENA) {
    while (ITM_Port32(0) == 0);
    ITM_Port8(0) = ch;
  }
  return(ch);
}
//------------------------------------------------------------------- //

volatile unsigned long * bit;
#define LED_Bit1   (*((volatile unsigned long *)0x23E7800C))
#define LED_Bit29  (*((volatile unsigned long *)0x23E786B4))
#define __FI        1   /* Font index 16x24               */
 

int main(void){

	
	//LEDs:
	int counter = 1;
	
	while(1){
				 
		if (counter == 1){
			//masking
			LPC_GPIO1->FIOPIN |= (1<<29);
      LPC_GPIO2->FIOPIN |= (1<<3);
			LPC_GPIO1->FIOPIN &= ~(1<<29);
      LPC_GPIO2->FIOPIN &= ~(1<<3);
		}
		
		else if(counter == 2){
			//function
			bit29 = &BitBand(0x2009C034, 29);	
			bit3 = &BitBand(0x2009C054, 3);	
			*bit3 = 0; //clearing
			*bit29 = 0;
			*bit3 = 1; //turning on
			*bit29 = 1;
			*bit3 = 0; //clearing
			*bit29 = 0;
		}
		else if(counter == 3){
			//Bit banding ON
			LED_Bit3 = 1; // turning on
			LED_Bit29 = 1; 
			LED_Bit3 = 0; // clearing 
			LED_Bit29 = 0;
		}
		
		else if (counter == 4){
			counter = 0;
		}
		counter++;
	}
	
	return 0;
}

