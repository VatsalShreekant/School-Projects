#include "LPC17xx.h"
#include <stdio.h>
#include "GLCD.h"
#include "bitband.h"

//------- ITM Stimulus Port definitions for printf ------------------- //
#define ITM_Port8(n)    (*((volatile unsigned char *)(0xE0000000+4*n)))
#define ITM_Port16(n)   (*((volatile unsigned short*)(0xE0000000+4*n)))
#define ITM_Port32(n)   (*((volatile unsigned long *)(0xE0000000+4*n)))
#define __USE_LCD   0
#define DEMCR           (*((volatile unsigned long *)(0xE000EDFC)))
#define TRCENA          0x01000000
const unsigned long led_mask[] = { 1UL<<28, 1UL<<29, 1UL<<31, 1UL<< 2,
                                   1UL<< 3, 1UL<< 4, 1UL<< 5, 1UL<< 6 };
struct __FILE { int handle;  };
FILE __stdout;
FILE __stdin;

int fputc(int ch, FILE *f) {
  if (DEMCR & TRCENA) {
    while (ITM_Port32(0) == 0);
    ITM_Port8(0) = ch;
  }
  return(ch);
}
//------------------------------------------------------------------- //

// Bit Band Macros used to calculate the alias address at run time
#define ADDRESS(x)    (*((volatile unsigned long *)(x)))
#define BitBand(x, y) 	ADDRESS(((unsigned long)(x) & 0xF0000000) | 0x02000000 |(((unsigned long)(x) & 0x000FFFFF) << 5) | ((y) << 2))
volatile unsigned long * bit3;
volatile unsigned long * bit29;
#define LED_Bit3   (*((volatile unsigned long *)0x23380A8C))
#define LED_Bit29  (*((volatile unsigned long *)0x233806E4))
#define __FI        1   /* Font index 16x24               */
int counter = 1;

void LED_Init(void){
		
	LPC_SC->PCONP     |= (1 << 15);            /* enable power to GPIO & IOCON  */
	LPC_GPIO1->FIODIR |= 0x2009C034;           /* LEDs on PORT1 are output      */
	LPC_GPIO2->FIODIR |= 0x2009C054;           /* LEDs on PORT2 are output      */
}
void delay(){
	int i = 0;
	while(i<1000){
		i++;
	}
}

int main(void){
#ifdef __USE_LCD
  GLCD_Init();                               /* Initialize graphical LCD (if enabled */

  GLCD_Clear(White);                         /* Clear graphical LCD display   */
  GLCD_SetBackColor(DarkGreen);
  GLCD_SetTextColor(White);
  GLCD_DisplayString(0, 0, __FI, "     COE718 Lab2    ");
	GLCD_DisplayString(1, 0, __FI, "     Vidhi Patel    ");
	
#endif
	LED_Init();
	//LEDs: P1.29, P2.3
	counter = 1;
			 
		while(1){
		
			if(counter == 1){
			//masking
			GLCD_DisplayString(6,  0, __FI,  "Masking mode:      ");
			LPC_GPIO1->FIOPIN |= led_mask[1];
      LPC_GPIO2->FIOPIN |= led_mask[4];
			delay();
			GLCD_DisplayString(6,  0, __FI,  "Delay              ");
			LPC_GPIO1->FIOPIN &= ~led_mask[1];
      LPC_GPIO2->FIOPIN &= ~led_mask[4];
			delay();			
			}
			
		else if(counter == 2){
			//function
			GLCD_DisplayString(6,  0, __FI,  "Functional mode:   ");
			bit29 = &BitBand(0x2009C034, 29);	
			bit3 = &BitBand(0x2009C054, 3);	
			*bit3 = 0; //clearing
			*bit29 = 0;
			GLCD_DisplayString(6,  0, __FI,  "Delay               ");
			delay();
			GLCD_DisplayString(6,  0, __FI,  "Functional mode     ");
			*bit3 = 1; //turning on
			*bit29 = 1;
			GLCD_DisplayString(6,  0, __FI,  "Delay               ");
			delay();
			*bit3 = 0; //clearing
			*bit29 = 0;
			GLCD_DisplayString(6,  0, __FI,  "Delay               ");
			delay();
		}
		else if(counter == 3){
			//Bit banding ON
			GLCD_DisplayString(6,  0, __FI,  "Bit Banding mode:  ");
			LED_Bit3 = 1; // turning on
			LED_Bit29 = 1; 
			GLCD_DisplayString(6,  0, __FI,  "Delay              ");
			delay();
			LED_Bit3 = 0; // clearing 
			LED_Bit29 = 0;
			GLCD_DisplayString(6,  0, __FI,  "Delay              ");
			delay();
		}
		else if (counter == 4){
			GLCD_DisplayString(6,  0, __FI,  "Delay              ");
			counter = 0;
		}
		counter++;
	}
}

