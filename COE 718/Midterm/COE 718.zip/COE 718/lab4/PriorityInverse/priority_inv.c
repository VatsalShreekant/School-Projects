/*----------------------------------------------------------------------------
	CMSIS RTX Priority Inversion Example
	Priority Inversion = leave commented lines commented
	Priority Elevation = uncomment the 2 commented lines
	Anita Tino
*----------------------------------------------------------------------------*/
#include "LPC17XX.h"
#include "cmsis_os.h"
#include "RTL.H"
#include "LED.h"
#include <stdbool.h>

void P1 (void const *argument);
void P2 (void const *argument);
void P3 (void const *argument);
_Bool mut = false;
osThreadDef(P1, osPriorityHigh, 1, 0);
osThreadDef(P2, osPriorityNormal, 1, 0);
osThreadDef(P3, osPriorityBelowNormal, 1, 0);

osThreadId t_main,t_P1,t_P2,t_P3;

void delay(){ 
	long k, count = 0;
	for(k = 0; k < 1000000; k++){
					count++;
			}
	}

void P1 (void const *argument) {
	for (;;) 
	{
		LED_On(0);
		delay(); //execute something, and after requires service from P3
		if (mut == true){
			osThreadSetPriority(t_P3, osPriorityHigh); //**solution uncomment
			osSignalSet(t_P3,0x01);						//call P3 to finish the task
			osSignalWait(0x02,osWaitForever);			//Error => priority inversion, P2 will run instead
			osThreadSetPriority(t_P3,osPriorityBelowNormal); //**solution uncomment
		}
		mut = false;		
		LED_Off(6);
	}
}

void P2 (void const *argument) {
	for (;;) 	{
		LED_On(1); 
		LED_Off(1); 
	}
}

void P3 (void const *argument) {
	for (;;) 	{
		mut = true;
		delay(); //do something
		osSignalWait(0x01,osWaitForever);  
		//osThreadSetPriority(t_P2, osPriorityHigh);
		LED_Off(0); //critical function to be requested by P1
		//osThreadSetPriority(t_P2,osPriorityBelowNormal);
		osSignalSet(t_P1,0x02);	 
	}
}

int main(void)
{
	LED_Init();
	t_main = osThreadGetId ();
	osThreadSetPriority(t_main,osPriorityHigh);
	t_P3 = osThreadCreate(osThread(P3), NULL);
	
	os_itv_set(500); //create thread t_P2 50ms after t_P3
	os_itv_wait();
	t_P2 = osThreadCreate(osThread(P2), NULL);
	
	os_itv_set(100);
	os_itv_wait();
	t_P1 = osThreadCreate(osThread(P1), NULL);
	
	osThreadTerminate(t_main);
	
	for (;;) {}
}
