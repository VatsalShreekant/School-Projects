/*#############################################################################/
	Using threads, signal, and wait for thread scheduling and synchronization
	CMSIS RTX Example
	Anita Tino
*#############################################################################*/
#include "LPC17xx.h"
#include "cmsis_os.h"
#include "RTL.H"
#include "LED.h"

void task_A (void const *argument);
void task_B (void const *argument);
void task_C (void const *argument);

osTimerId timer_0;
osTimerId timer_1;
osTimerId timer_2;


osThreadDef(task_A, osPriorityBelowNormal, 1, 0);
osThreadDef(task_B, osPriorityNormal, 1, 0);
osThreadDef(task_C, osPriorityAboveNormal, 1, 0);

/*###########################################################
	Virtual Timer declaration and call back method
############################################################*/
osThreadId T_led_ID1;
osThreadId T_led_ID2;	
osThreadId T_led_ID3;	
void delay(int i)
{
int k;
int j = i * 20000;
for( k=0;k<j;k++){}
}

// Toggle the LED associated with the timer
void callback(void const *param){
	switch( (uint32_t) param){
		case 0:
			osSignalSet	(T_led_ID1,0x0A);
			break;
		case 1:
			osSignalSet	(T_led_ID2,0x0B);	
		  break;
		case 2:
			osSignalSet	(T_led_ID3,0x0C);
			break;		
	}
}

osTimerDef(timer0_handle, callback);
osTimerDef(timer1_handle, callback);
osTimerDef(timer2_handle, callback);
//#############################################################

/*#############################################################
  Flash LED 0, signal to thread 2, wait for 3 to finish
*#############################################################*/
void task_A (void const *argument) {
	for (;;) {
		LED_On(0);
	//	LED_On(1);
		delay(20);
		LED_Off(0);
		//LED_Off(1);
		osSignalWait (0x0A,osWaitForever);
	}
}

/*################################################################
  Flash LED 2, signal to thread 3, wait for thread 1 to finish
*################################################################*/
void task_B (void const *argument) {
	for (;;) 	{
		LED_On(2);	
		//LED_On(3);
		delay(10);	
		LED_Off(2);
		//LED_Off(3);
		osSignalWait (0x0B,osWaitForever);
	}
}

/*################################################################
  Flash LED 4, signal to thread 1, wait for thread 2 to finish
*################################################################*/
void task_C (void const *argument){
	for (;;) 	{
		LED_On(4);
		//LED_On(5);
		delay(5);
		LED_Off(4);
		//LED_Off(5);
		osSignalWait (0x0C,osWaitForever);
	}
}

/*###################################################################
  Create and start threads
 *###################################################################*/
int main (void) {
		LED_Init ();
	//Virtual timer create and start
	osThreadSetPriority(osThreadGetId() ,osPriorityHigh);
	timer_0 = osTimerCreate(osTimer(timer0_handle), osTimerPeriodic, (void *)0);	
	timer_1 = osTimerCreate(osTimer(timer1_handle), osTimerPeriodic, (void *)1);	
	timer_2 = osTimerCreate(osTimer(timer2_handle), osTimerPeriodic, (void *)2);
	
	//Signal and wait threads
	T_led_ID1 = osThreadCreate(osThread(task_A), NULL);
	T_led_ID2 = osThreadCreate(osThread(task_B), NULL);
	T_led_ID3 = osThreadCreate(osThread(task_C), NULL);
	
	
		
	osTimerStart(timer_0, 400);	
	osTimerStart(timer_1, 400);	
	osTimerStart(timer_2, 200);	
	
	osDelay(osWaitForever);               						
	
	for (;;);
}

