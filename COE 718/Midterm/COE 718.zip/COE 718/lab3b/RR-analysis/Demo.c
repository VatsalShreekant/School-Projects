/*************************************************************
	COE718 Lab 3 Demo.c file
	Understanding different scheduling algorithms with RTX
	Anita Tino
*************************************************************/

#include "LPC17xx.H"              // LPC17xx definitions      
#include <stdio.h>                                  
#include <ctype.h>                    
#include <string.h>                   
#include <stdbool.h>
#include "cmsis_os.h"
#include "RTL.H"		// RTX header file
#include <math.h>
#define COUNTER   1000000


unsigned int counta = 1; //global task counters
unsigned int countb = 1;
unsigned int countc = 1;
   

__task void task1 (void const *arg) {  // __task is an RTX keyword
	  		while(counta < COUNTER){
					counta = 2*pow(2,counta);
					counta++;
				}
}

__task void task2 (void const *arg) {
		while(countb < COUNTER){
				countb = 4*pow(3,countb);
		}
}


__task void task3 (void const *arg) {
		while(countc < COUNTER){
				countc = countc*5;
		}		
}

//create a thread for the function task1 and task2 with normal priority
osThreadDef (task1, osPriorityNormal, 1, 0); 
osThreadDef (task2, osPriorityNormal, 1, 0);
osThreadDef (task3, osPriorityNormal, 1, 0);

int main (void) {
	SystemInit(); // initialize the Coretx-M3 processor 
	osKernelInitialize ();   // setup kernel
	osThreadCreate (osThread(task1), NULL);   // create threads
 	osThreadCreate (osThread(task2), NULL); 
	osThreadCreate (osThread(task3), NULL); 
 	osKernelStart ();       // start kernel
	osDelay(osWaitForever);
}
