/*************************************************************
	COE718 Lab 3 Demo.c file
	Understanding different scheduling algorithms with RTX
	Anita Tino
*************************************************************/

#include "LPC17xx.H"              // LPC17xx definitions      
#include <stdio.h>                                  
#include <ctype.h>                    
#include <string.h>                   
#include <stdbool.h>
#include "cmsis_os.h"
#include <math.h>
#include "RTL.H"		// RTX header file#include "LED.h"
#define PI 3.14159265358979323846
#define COUNTER   1000000


unsigned int counta = 0; //global task counters
unsigned int countb = 0;
unsigned int countc = 0;
unsigned int countd = 0;
double counte = 0;

int x;
int n;
int i;

void time_delay(int time){
	int i =0;
	while(i<time){i++;}
}

long int factorial(int n)
{
	if (n >= 1)
		return n*factorial(n-1);
	else 
		return 1;
}
__task void taskA (void const *arg) {  // __task is an RTX keyword

	for (x = 0; x<256;x++){
		counta += x + (x+2);
		 os_tsk_pass();
	}
		
}

__task void taskB (void const *arg) {
 for (n = 1; n<=16 ;n++){
		countb += pow(2,n)/(factorial(n));
	 os_tsk_pass();
	}
}

__task void taskC (void const *arg) {
	for (n = 1; n<17;n++){
		countc += (n+1)/n;
		os_tsk_pass();
	}
}

__task void taskD (void const *arg) {
	for (i = 1; i<=5;i++){
		countd = 1 + pow(5,i)/factorial(i) + countd;
		 os_tsk_pass();
	}
}
__task void taskE (void const *arg) {
	double r = 10;
	for ( n = 1; n<=12;n++){
		counte = n*PI*r*r + counte;
		 os_tsk_pass();
	}
}
//create a thread for the function task1 and task2 with normal priority
osThreadDef (taskA, osPriorityAboveNormal, 1, 0); 
osThreadDef (taskB, osPriorityNormal, 1, 0);
osThreadDef (taskC, osPriorityHigh, 1, 0);
osThreadDef (taskD, osPriorityAboveNormal, 1, 0);
osThreadDef (taskE, osPriorityNormal, 1, 0);
int main (void) {
	SystemInit(); // initialize the Coretx-M3 processor 
	osKernelInitialize ();   // setup kernel
	osThreadCreate (osThread(taskC), NULL); 
	osThreadCreate (osThread(taskA), NULL);   // create threads
	osThreadCreate (osThread(taskD), NULL);
 	osThreadCreate (osThread(taskB), NULL);  
	osThreadCreate (osThread(taskE), NULL); 
	
 	osKernelStart ();       // start kernel
	osDelay(osWaitForever);
}
