/*************************************************************
	COE718 Lab 3 Demo.c file
	Understanding different scheduling algorithms with RTX
	Anita Tino
*************************************************************/

#include "LPC17xx.H"              // LPC17xx definitions      
#include <stdio.h>                                  
#include <ctype.h>                    
#include <string.h>                   
#include <stdbool.h>
#include "cmsis_os.h"
#include "RTL.H"		// RTX header file
#include "LED.h"
#include <math.h>
#include "GLCD.h"

#define __USE_LCD   0
#define PI 3.1415
#define COUNTER   1000000
#define __FI        1   /* Font index 16x24     */   
#define __FI0       1   /* Font index 16x24     */


double counta = 0; //global task counters
double countb = 0;
double countc = 0;
double countd = 1;
double counte = 0;
char text[8];
int x;
int n;
int i;

void time_delay(int time){
	int i =0;
	while(i<time){i++;}
}

long int factorial(int n)
{
	if (n >= 1)
		return n*factorial(n-1);
	else 
		return 1;
}
__task void LCD (void const *arg) {
	                      
		GLCD_Clear(White); // Clear graphical LCD display   
	GLCD_SetBackColor(Purple);
	GLCD_SetTextColor(White);
	GLCD_DisplayString(0, 0, __FI, "     COE718 Lab3b      ");
	GLCD_DisplayString(1, 0, __FI, "     Pre-emptive      ");
	GLCD_SetBackColor(White);
	GLCD_SetTextColor(Purple);  
	GLCD_DisplayString(4, 0, __FI0, "TASK A: ");	
	GLCD_DisplayString(5, 0, __FI0, "TASK B: ");
	GLCD_DisplayString(6, 0, __FI0, "TASK C: ");
	GLCD_DisplayString(7, 0, __FI0, "TASK D: ");
	GLCD_DisplayString(8, 0, __FI0, "TASK E: ");
	GLCD_SetBackColor(White);
	GLCD_SetTextColor(Purple); 
	os_tsk_delete_self();
}
__task void taskA (void const *arg) {  // __task is an RTX keyword

	for (x = 0; x<=256;x++){
		counta += (float)(x + (x+2));	
	}
		LED_On(1);		
		sprintf(text, " %lf ", counta); 	
		GLCD_SetBackColor(White);
		GLCD_DisplayString(4, 7, __FI0, (unsigned char *)text);	
		time_delay(1000000);
		os_tsk_delete_self();
}

__task void taskB (void const *arg) {
	
 for (n = 1; n<=16 ;n++){
		countb += (pow(2,n)/(float)(factorial(n)));
	 
	} LED_On(2);
		GLCD_SetBackColor(White);
		sprintf(text, " %lf", countb); 
		GLCD_DisplayString(5, 7, __FI0, (unsigned char *)text);		
	time_delay(1000000);
 	 os_tsk_delete_self();
}

__task void taskC (void const *arg) {
	
	for (n = 1; n<17;n++){
		countc += ((float)(n+1)/(float)n);
	}
		LED_On(3);
		time_delay(1000000);
		GLCD_SetBackColor(White);
	GLCD_SetTextColor(Green);  
		sprintf(text, "%lf", countc); 
		GLCD_DisplayString(6, 7, __FI0, (unsigned char *)text);
		os_tsk_delete_self();
}

__task void taskD (void const *arg) {
	
	for (i = 1; i<=5;i++){
		countd =  ((float)pow(5,i)/(float)factorial(i)) + countd;
		
	}
		LED_On(4);
	GLCD_SetBackColor(White);	
	sprintf(text, "c%lf ", countd); 
		GLCD_DisplayString(7, 7, __FI0, (unsigned char *)text);
		time_delay(1000000);
		 os_tsk_delete_self();
}
__task void taskE (void const *arg) {
	double r = 1;
	
	for ( n = 1; n<=12;n++){
		counte += (n*PI*r*r) ; 
		
	}
	LED_On(5);
	GLCD_SetBackColor(White);
	GLCD_SetTextColor(White);  
	sprintf(text, "Counte = %lf  ", counte); 
	GLCD_DisplayString(8, 7, __FI0, (unsigned char *)text);
	time_delay(1000000);
	os_tsk_delete_self(); 
}
//create a thread for the function task1 and task2 with normal priority

osThreadDef (LCD, osPriorityRealtime, 1, 0); 
osThreadDef (taskA, osPriorityAboveNormal, 1, 0); 
osThreadDef (taskB, osPriorityLow, 1, 0);
osThreadDef (taskC, osPriorityHigh, 1, 0);
osThreadDef (taskD, osPriorityAboveNormal, 1, 0);
osThreadDef (taskE, osPriorityLow, 1, 0);

int main (void) {
	SystemInit(); // initialize the Coretx-M3 processor 
	LED_Init();
	GLCD_Init();

	osKernelInitialize ();   // setup kernel
	osThreadCreate (osThread(LCD), NULL); 
	osThreadCreate (osThread(taskC), NULL); 
	osThreadCreate (osThread(taskA), NULL);   // create threads
	osThreadCreate (osThread(taskD), NULL);
 	osThreadCreate (osThread(taskB), NULL);  
	osThreadCreate (osThread(taskE), NULL); 
 	osKernelStart ();       // start kernel	
	osDelay(osWaitForever);
}
