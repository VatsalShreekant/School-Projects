/*************************************************************
	COE718 Lab 3 Demo.c file
	Understanding different scheduling algorithms with RTX
	Anita Tino
*************************************************************/

#include "LPC17xx.H"              // LPC17xx definitions      
#include <stdio.h>                                  
#include <ctype.h>                    
#include <string.h>                   
#include <stdbool.h>
#include "cmsis_os.h"
#include "RTL.H"		// RTX header file
#include "LED.h"
#include <math.h>
#include "GLCD.h"

#define COUNTER   100000
#define __FI        1   /* Font index 16x24     */  

unsigned int counta = 1; //global task counters
unsigned int countb = 1;
unsigned int countc = 1;
char text[10];
char text2[10];
char text3[10];
osSemaphoreId semaphore;                         // Semaphore ID
osSemaphoreDef(semaphore);  
void time_delay(int time){
	int i =0;
	while(i<time){i++;}
}

__task void task1 (void const *arg) {  // __task is an RTX keyword

	while(counta < COUNTER){
				counta = 2*pow(2,counta);
				counta++;
				LED_Out(0xFF);
				GLCD_DisplayString(3, 0, __FI, "TASK 1:");
				sprintf(text, "Counta =%d", counta); 
				GLCD_DisplayString(3, 9, __FI, (unsigned char *)text);
				time_delay(1000000);
			
	}
}

__task void task2 (void const *arg) {
 
	while(countb < COUNTER){
				countb = 4*pow(3,countb);
				LED_Out(0xFC);
				GLCD_DisplayString(4, 0, __FI, "TASK 2:");
				sprintf(text, "Countb =%d", countb); 
				GLCD_DisplayString(4, 9, __FI, (unsigned char *)text);
				time_delay(1000000);		
	}
			
}


__task void task3 (void const *arg) {
 
	while(countc < COUNTER){
		countc = countc*5;
		LED_Out(0xF0);
		GLCD_DisplayString(5, 0, __FI, "TASK 3:");
		sprintf(text, "Countc =%d", countc); 
		GLCD_DisplayString(5, 9, __FI, (unsigned char *)text);
		time_delay(1000000);		
	}		
}


//create a thread for the function task1 and task2 with normal priority
osThreadDef (task1, osPriorityNormal, 1, 0); 
osThreadDef (task2, osPriorityNormal, 1, 0);
osThreadDef (task3, osPriorityNormal, 1, 0);

int main (void) {
	
	LED_Init();
	GLCD_Init();
	GLCD_Clear(White); 
	SystemInit(); // initialize the Coretx-M3 processor 
	osKernelInitialize ();   // setup kernel
	
	osThreadCreate (osThread(task1), NULL);   // create threads
 	osThreadCreate (osThread(task2), NULL); 
	osThreadCreate (osThread(task3), NULL); 
 	osKernelStart ();       // start kernel
	osDelay(osWaitForever);
}
