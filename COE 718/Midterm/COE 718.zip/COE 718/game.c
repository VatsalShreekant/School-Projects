#include "stdio.h"

#define BORDER  '|'
#define PLAYER1  'X'
#define PLAYER2  'O'
#define EMPTY   '-'
const char player [2]= {'X', 'O'};
const int convertTo9[9] = {6,7,8,11,12,13,16,17,18};
void Intialize (int *board)
{
	int index = 0;
	
	for (index =0; index < 25; index++)
	{
		board[index] = BORDER;
	}
	for (index =0; index < 25; index++)
	{
		board[convertTo9[index]] = EMPTY;
	}
}
void printBoard(const int *board)
{
		int index = 0;
	printf ("\nBOARD\n");
	for (index =0; index < 25; index++)
	{
		if (index!=0 && index%5 ==0){printf("\n");}
		printf ("%4d", board[index]);
	}
	printf("\n");
}

int  main ()
{
	int board[25];
	Intialize(&board[0]);
	printBoard(&board[0]);
	return 0;
}