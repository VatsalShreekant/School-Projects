/*-----------------------------------------------------------------------------
 * Name:    Demo.c
 * Purpose: Demo example for MCB1700
 * Note(s):
 *-----------------------------------------------------------------------------
 * This file is part of the uVision/ARM development tools.
 * This software may only be used under the terms of a valid, current,
 * end user licence from KEIL for a compatible version of KEIL software
 * development tools. Nothing else gives you the right to use this software.
 *
 * This software is supplied "AS IS" without warranties of any kind.
 *
 * Copyright (c) 2004-2014 Keil - An ARM Company. All rights reserved.
 *----------------------------------------------------------------------------*/

#include "LPC17xx.h"
#include "cmsis_os.h"
#include <stdio.h>
#include "Board_LED.h"
#include "Board_Buttons.h"
#include "Board_Joystick.h"
#include "Board_ADC.h"
#include "Board_GLCD.h"
#include "GLCD_Config.h"

extern GLCD_FONT GLCD_Font_6x8;
extern GLCD_FONT GLCD_Font_16x24;


/* Joystick position definitions */
#define JOY_X        (9*16)
#define JOY_Y        (5*24 + 6)

/* Buttons bit masks */
#define BTN_INT0     (1 << 0)


/* Periodic timer definition */
void Timer_Callback (void const *arg);
osTimerDef (PeriodicTimer, Timer_Callback);
osTimerId TimerId;

 
/* GLCD string buffer */
#define STRINGBUF_LEN 21

char            StringBuf[STRINGBUF_LEN];

/* Extern variables */
extern uint8_t  Arrows_16bpp_red[];
extern uint8_t  Button_16bpp[];
extern uint8_t  Bulb_16bpp[];

/* Static variables */
static uint32_t LEDOn, LEDOff;
static int32_t  LEDDir = 1;


/*-----------------------------------------------------------------------------
  Periodic timer callback
 *----------------------------------------------------------------------------*/
void Timer_Callback (void const *arg) {
  static uint8_t TickLed;
  
  switch (TickLed++) {
    case  1: LEDOn   = 1; break;
    case  6: LEDOff  = 1; break;
    case 10: TickLed = 0; break;
  }
}



/*-----------------------------------------------------------------------------
  Blink LEDs
 *----------------------------------------------------------------------------*/
void BlinkLed (void) {
  int32_t max_num = LED_GetCount() - 1;
  static int32_t num;

  if (LEDOn) {
    LEDOn = 0;
    LED_On (num);                         /* Turn specified LED on            */
  }

  if (LEDOff) {
    LEDOff = 0;
    LED_Off (num);                        /* Turn specified LED off           */

    num += LEDDir;                        /* Change LED number                */
    
    if (LEDDir == 1 && num == max_num) {
      LEDDir = -1;                        /* Change direction to down         */
    }
    else if (num == 0) {
      LEDDir =  1;                        /* Change direction to up           */
    }
  }
}

/*-----------------------------------------------------------------------------
  Main function
 *----------------------------------------------------------------------------*/
int main (void) {
  uint32_t    ofs;
  uint32_t    btnMsk, joyMsk;
  int32_t     adcVal;
  int32_t     joy  = -1;
  int32_t     adc  = -1;
  int32_t     btn  = -1;

  TimerId = osTimerCreate (osTimer(PeriodicTimer), osTimerPeriodic, NULL);
  
  if (TimerId) {
    osTimerStart (TimerId, 100);
  }
  
  ADC_Initialize          ();           /* Initialize A/D Converter           */
  GLCD_Initialize         ();           /* Initialize Graphical LCD           */
  Joystick_Initialize     ();           /* Initialize joystick                */
  LED_Initialize          ();           /* Initialize LED                     */

  /* Prepare display for ADC, Buttons, Joystick */
  GLCD_SetBackgroundColor (GLCD_COLOR_BLUE);
  GLCD_SetForegroundColor (GLCD_COLOR_WHITE);
  GLCD_SetFont            (&GLCD_Font_16x24);
  GLCD_DrawString         (0, 0*24, "       MCB1700      ");
  GLCD_DrawString         (0, 1*24, "    Demo Example    ");
  GLCD_SetBackgroundColor (GLCD_COLOR_WHITE);
  GLCD_SetForegroundColor (GLCD_COLOR_BLUE);
  GLCD_DrawString         (0, 2*24, "                    ");
  GLCD_DrawString         (0, 3*24, "AD value:           ");
  GLCD_DrawString         (0, 4*24, "Buttons :           ");
  GLCD_DrawString         (0, 5*24, "                    ");
  GLCD_DrawString         (0, 6*24, "Joystick:           ");
  GLCD_DrawString         (0, 7*24, "                    ");
  GLCD_DrawString         (0, 8*24, "                    ");
  GLCD_DrawString         (0, 9*24, "                    ");

  while (1) {
    BlinkLed();

    btnMsk = Buttons_GetState();    /* Show buttons state                 */
    if (btn ^ btnMsk) {
      btn = btnMsk;
      GLCD_SetForegroundColor   (GLCD_COLOR_BLACK);
      GLCD_SetFont              (&GLCD_Font_16x24);
      if (btnMsk & BTN_INT0)    { GLCD_DrawString ( 9*16, 4*24, "INT0"); }

      GLCD_SetForegroundColor (GLCD_COLOR_LIGHT_GREY);
      if (!(btnMsk & BTN_INT0)) { GLCD_DrawString ( 9*16, 4*24, "INT0"); }
    }
    
    joyMsk = Joystick_GetState();   /* Show joystick arrows               */
    if (joy ^ joyMsk) {
      joy = joyMsk;
    
      /* Left arrow white/red? */
      ofs = (joy & JOYSTICK_LEFT)   ? (2416) : (0);
      GLCD_DrawBitmap(JOY_X+ 0, JOY_Y+20, 19, 14, &Arrows_16bpp_red[ofs + 0*532]);
    
      /* Right arrow white/red? */
      ofs = (joy & JOYSTICK_RIGHT)  ? (2416) : (0);
      GLCD_DrawBitmap(JOY_X+35, JOY_Y+20, 19, 14, &Arrows_16bpp_red[ofs + 1*532]);
    
      /* Center dot white/red */
      ofs = (joy & JOYSTICK_CENTER) ? (2416) : (0);
      GLCD_DrawBitmap(JOY_X+21, JOY_Y+21, 12, 12, &Arrows_16bpp_red[ofs + 4*532]);
    
      /* Up arrow white/red? */
      ofs = (joy & JOYSTICK_UP)     ? (2416) : (0);
      GLCD_DrawBitmap(JOY_X+20, JOY_Y+ 0, 14, 19, &Arrows_16bpp_red[ofs + 2*532]);
    
      /* Down arrow white/red? */
      ofs = (joy & JOYSTICK_DOWN)   ? (2416) : (0);
      GLCD_DrawBitmap(JOY_X+20, JOY_Y+35, 14, 19, &Arrows_16bpp_red[ofs + 3*532]);
    }
    
    ADC_StartConversion();          /* Show A/D conversion bargraph       */
    adcVal = ADC_GetValue();
    if ((adcVal != -1) && (adc ^ adcVal)) {
      adc = adcVal;
      GLCD_SetForegroundColor (GLCD_COLOR_GREEN);
      GLCD_DrawBargraph       (144, 3*24, 160, 20, (adcVal * 100) / ((1 << ADC_GetResolution()) - 1));
    }
  }
}
