/*----------------------------------------------------------------------------
 * Final Project Joinable Threads Demo
 *---------------------------------------------------------------------------*/
 
#include "RTE_Components.h"
#include  CMSIS_device_header
#include "cmsis_os2.h"
#include "Board_LED.h"                  


//Declare Threads
osThreadId_t app_THREAD,THREAD1,THREAD2;  


// Declare counter 
int counter1 = 0; 
int counter2 = 0;
int counter3 = 0;

// Delay Function 
void delay ()
{
 int i;

	for(i =0;i<750000;i++){
		;
	}
}

static const osThreadAttr_t ThreadAttr_Jthread = {
	.name = "Joinable Thread",
	.attr_bits = osThreadJoinable,
	.priority = osPriorityAboveNormal,
};

void joinable_thread (void *argument) {

		switch((uint32_t)argument){
			
			case 1 : 
			
				LED_On(0);   // Port 1
				delay();
				LED_On(1);
				delay();
				LED_On(2); 
				delay();
				LED_On(3);	 // Port 2 
				delay();
				LED_On(4);
				delay();
				LED_On(5); 
				delay();
				LED_On(6);
				delay();
				LED_On(7);
				delay();
				LED_On(8); 
				counter1 = counter1 + 1;
					break;
			
			case 0:
		
				LED_Off(8);  // Port 2 
				delay();
				LED_Off(7);
				delay();
				LED_Off(6); 
				delay();
				LED_Off(5);	 
				delay();
				LED_Off(4);
				delay();
				LED_Off(3);  // Port 1
				delay();
				LED_Off(2);
				delay();
				LED_Off(1);
				counter2 = counter2 + counter1;
					break;
		}
		osThreadExit();
}


// Attribute main thread
static const osThreadAttr_t ThreadAttr_mainthread = {
	.name = "mainthread",
	.priority = osPriorityAboveNormal,	
};


// Create joinable threads off of main app thread
__NO_RETURN void main_thread1 (void *argument) {
  
	for (;;) {
		THREAD1  = osThreadNew(joinable_thread,(void *) 1U, &ThreadAttr_Jthread);     //Create 2nd thread             																												
		counter3 = counter1*counter2;
		delay();
		osThreadJoin(THREAD1);																												//Join Thread
		THREAD2  = osThreadNew(joinable_thread,(void *) 0U, &ThreadAttr_Jthread);			//Create 3rd thread
		counter3 = counter3/2; 
		osThreadJoin(THREAD2);																												//Join Thread
		delay(); 
	}
}

// Default template main.c 
int main (void) {
 
  SystemCoreClockUpdate();
  osKernelInitialize();                 								// Initialize CMSIS-RTOS

  app_THREAD = osThreadNew(main_thread1, NULL, &ThreadAttr_mainthread);  // create new main_thread1
	
	LED_Initialize();
	osKernelStart();                     									// Start thread execution
  
	for (;;) {}
}
