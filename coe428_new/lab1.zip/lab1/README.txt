A mySort() function with the signature used in this lab could exploit better sorting function in the supplied object module by calling the betterSort() function by calling betterSort(d, 0, n-1).


Everything worked.
For the duration of the lab, Parth Patel provided assistance and we worked together.  
