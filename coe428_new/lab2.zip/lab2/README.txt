1. towers (4,2,1)
2. 5
3. 2 3
4. towers(0,1,3)
5. 255

Everything worked perfectly, consulted with Alexander and James. 
