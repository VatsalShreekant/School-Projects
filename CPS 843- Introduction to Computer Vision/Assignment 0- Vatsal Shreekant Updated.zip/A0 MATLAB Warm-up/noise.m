img = imread('female.tiff');
meanValue = double(mean(img(:)));
% varValue = double(var(img(:)));
img_noise = imnoise(img, 'gaussian')*0.8;
subplot(1,2,1), imshow(img), title('Original')
subplot(1,2,2), imshow(img_noise), title('Q-5')