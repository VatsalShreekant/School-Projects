img_1 = imread('female.tiff');
img_2 = imread('house.tiff');
[rows, columns, numOfColorChannels] = size(img_1);
[rows_2, columns_2, numOfColorChannels_2] = size(img_2);

x_0 = double((rows/2)-50);
y_0 = double((columns/2)-50);
x_new = double(x_0 + 100);
y_new = double(y_0 + 100);
img_1_gray = rgb2gray(img_1);

x_0_2 = double((rows_2/2)-50);
y_0_2 = double((columns/2)-50);
x_new_2 = double(x_0_2 + 100);
y_new_2 = double(y_0_2 + 100);
img_2_gray = rgb2gray(img_2);


img_1_cropped = uint8(img_1_gray(x_0:x_new, y_0:y_new, :));
img_2_edited = uint8(img_2_gray);
img_2_edited(x_0_2:x_new_2, y_0_2:y_new_2,:) = uint8(img_1_gray(x_0:x_new, y_0:y_new, :));
% img_cropped = imcrop(img(x_0:x_new, y_0:y_new));
figure (1)
subplot(1,3,1), imshow(img_1), title('Original Image 1')
subplot(1,3,2), imshow(img_1_gray), title('Greyscale Image 1')
subplot(1,3,3), imshow(img_1_cropped), title('100x100 pixels')

figure (2)
subplot(1,3,1), imshow(img_2), title('Original Image 2')
subplot(1,3,2), imshow(img_2_gray), title('Grayscale Image 2')
subplot(1,3,3), imshow(img_2_edited), title('Grayscale Image 2 Edited')