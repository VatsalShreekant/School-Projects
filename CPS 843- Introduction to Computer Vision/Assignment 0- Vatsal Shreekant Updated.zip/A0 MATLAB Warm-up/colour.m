img = imread('female.tiff');
new_img(:,:,1) = uint8(img(:,:,3));
new_img(:,:,2) = uint8(img(:,:,2));
new_img(:,:,3) = uint8(img(:,:,2));
figure (1)
subplot(1,2,1), imshow(img), title('Original')
subplot(1,2,2), imshow(new_img), title('Red Swapped with Blue')

greenFilter = uint8(img(:,:,2));
cancel = zeros(size(img, 1), size(img, 2), 'uint8');
img_g = cat(3,cancel,greenFilter,cancel);
figure (2)
subplot(1,2,1), imshow(img), title('Original')
subplot(1,2,2), imshow(img_g), title('Monochrome: Green Channel')

redFilter = uint8(img(:,:,1));
img_r = cat(3,redFilter,cancel,cancel);
figure(3)
subplot(1,2,1), imshow(img), title('Original')
subplot(1,2,2), imshow(img_r), title('Monochrome: Red Channel')

img_gray = rgb2gray(img);
figure(4)
subplot(1,2,1), imshow(img), title('Original')
subplot(1,2,2), imshow(img_gray), title('Grayscale')

