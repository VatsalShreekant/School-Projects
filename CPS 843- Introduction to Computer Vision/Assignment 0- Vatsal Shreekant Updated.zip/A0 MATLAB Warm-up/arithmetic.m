img = imread('female.tiff');
greenFilter = uint8(img(:,:,2));
cancel = zeros(size(img, 1), size(img, 2), 'uint8');
img_g = cat(3,cancel,greenFilter,cancel);

minValue = uint8(min(img_g(:)));
maxValue = uint8(max(img_g(:)));
fprintf('The minimum and maximum pixel values of img_g are:\n');
disp(minValue);
disp(maxValue);

meanValue = double(mean(img_g(:)));
fprintf('The mean value of img_g is:\n');
disp(meanValue);

stdValue = double(std2(img_g(:)));
fprintf('The standard deviation value of img_g is:\n');
disp(stdValue);

meanValueImg = img_g - meanValue;
stdValueImg = meanValueImg/stdValue;
multValueImg = stdValueImg*10;
meanAddedImg = multValueImg + meanValue;

figure(1)
subplot(1,2,1), imshow(img), title('Original')
subplot(1,2,2), imshow(meanAddedImg), title('Q-4) Part-b')

shiftLeftImg = imtranslate(img_g,[-2,0]);
figure(2)
subplot(1,2,1), imshow(img_g), title('Original')
subplot(1,2,2), imshow(shiftLeftImg), title('Q-4) Part-c')

shiftedSubOrigImg = im2double(img_g - shiftLeftImg);
figure(3)
subplot(1,3,1), imshow(img_g), title('Original')
subplot(1,3,2), imshow(shiftLeftImg), title('Q-4) Part-c')
subplot(1,3,3), imshow(shiftedSubOrigImg), title('Q-4) Part-d')

img_g_flipped = fliplr(img_g);
figure(4)
subplot(1,2,1), imshow(img_g), title('Original')
subplot(1,2,2), imshow(img_g_flipped), title('Q-4) Part-e')

img_g_complement = imcomplement(img_g);
figure(5)
subplot(1,2,1), imshow(img_g), title('Original')
subplot(1,2,2), imshow(img_g_complement), title('Q-4) Part-f')

