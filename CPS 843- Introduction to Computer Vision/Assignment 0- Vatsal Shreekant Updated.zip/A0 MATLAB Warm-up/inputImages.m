female = imread('female.tiff');
house = imread('house.tiff');
figure (1)
subplot(1,2,1), imshow(female), title('Image 1')
subplot(1,2,2), imshow(house), title('Image 2')
