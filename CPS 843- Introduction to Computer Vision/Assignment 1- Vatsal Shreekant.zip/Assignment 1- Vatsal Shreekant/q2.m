%% Question 2 
img = imread('bowl-of-fruit.jpg');
figure('Name', 'Original Image'); imshow(img, []);
pause
img_gray = rgb2gray(img);
img_edge = MyCanny(img_gray,3,10);
figure('Name', 'Image With Edges'); imshow(img_edge, []);

function img_edges = MyCanny(input_img, std_deviation, tau)
    
    input_img = double(input_img);
    
    img_Size = size(input_img);
    img_Height = img_Size(1);
    img_Wide = img_Size(2);
    
    kernel = fspecial('gaussian', [5 5], std_deviation);
    h = fspecial('sobel');
    
    der_Filter = imfilter(kernel, h, 'conv');
    
    x_der_img = imfilter(input_img, der_Filter', 'conv');
    y_der_img = imfilter(input_img, der_Filter, 'conv');
    x_der_sq = x_der_img*x_der_img;
    y_der_sq = y_der_img*y_der_img;
    img_gradient = sqrt(x_der_sq + y_der_sq);
    img_gradient_a = atan2(y_der_img, x_der_img);
     
    img_gradient = (img_gradient(:, :) > tau) .* img_gradient;
    
    img_edges = zeros(img_Height, img_Wide);
%     
    for(i = 2 : img_Height - 1) 
        for(j = 2 : img_Wide - 1)
            pixelm = img_gradient(i,j);
            pixe_val = abs(img_gradient_a(i,j));
            
             
            if(pixe_val >=0 && pixe_val < (pi/6)) || (pixe_val <= pi && pixe_val >= (5*pi/6))
                if pixelm > img_gradient(i, j-1) && pixelm > img_gradient(i, j+1)
                    img_edges(i, j) = 1;
                end
            end
        end
    end

    
    figure('Name', 'Image with Edges');imshow(img_edges, [])
    
    img_edges = img_edges;
    
end




