% Question 1.4
function [convoluted_image] = MyConv(input_img,kernel)
  [rws,cls] = size(input_img);
  img = im2double(imread(input_img));
  %Padding image with zeroes
  img_padded = padarray(img,[5 5]);
  img_final = zeros([size(img,1) size(img,2)]);


  % Convolution 
for i = 1:size(img_padded,1)-2
    for j = 1:size(img_padded,2)-2
        Temp = img_padded(i:i+2,j:j+2).*kernel;
        img_final(i,j) = sum(Temp(:));
    end
end
 
  %Convolution for non-padded
for i = 1:size(img,1)-2
    for j = 1:size(img,2)-2
        Temp = img(i:i+2,j:j+2).*kernel;
        img_final_np(i,j) = sum(Temp(:));
    end
 end

display(img_final);
figure(1)
subplot(1,4,1), imshow(img), title('Original')
subplot(1,4,2), imshow(img_padded), title('Padded')
subplot(1,4,3), imshow(img_final), title('Final')
subplot(1,4,4), imshow(img_final_np), title('Final No Pad')


% 2D Gaussian kernel with hsize = 13 and sigma = 2
dimension = 13;
std_dev = 2;
kernel_new = fspecial('gaussian',dimension,std_dev);

img2 = im2double(imread(input_img));

imfilter_image = imfilter(img2,kernel_new);
R = size(imfilter_image);
fprintf('Imfilter size:');
disp(R);
S = size(img_final_np);
fprintf('Non-padded Image Size:');
disp(S);

T = size(img_final);
fprintf('Padded Image size:');
disp(T);
figure(2), imshow(imfilter_image), title('Using imfilter')

abs_difference = imabsdiff(imfilter_image,img_final);
figure(3), imshow(abs_difference), title('Absolute Difference');

fprintf('With the imfilter, the image becomes dark.');

