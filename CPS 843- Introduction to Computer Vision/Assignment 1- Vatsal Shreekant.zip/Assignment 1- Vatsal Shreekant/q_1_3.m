% Question 1.3
function [convoluted_image] = MyConv(input_img,kernel)
  %[rws,cls] = size(input_img);
  img = im2double(imread(input_img));
  %Padding image with zeroes
  img_padded = padarray(img,[5 5]);
  img_final = zeros([size(img,1) size(img,2)]);


  % Convolution 
for i = 1:size(img_padded,1)-2
    for j = 1:size(img_padded,2)-2
        Temp = img_padded(i:i+2,j:j+2).*kernel;
        img_final(i,j) = sum(Temp(:));
    end
 end

disp(img_final);
figure(1)
subplot(1,3,1), imshow(img), title('Original')
subplot(1,3,2), imshow(img_padded), title('Padded')
subplot(1,3,3), imshow(img_final), title('Final')
 


