%% Question 1.1
q_1_1 = [ -5  0  0  0  0  0  0  0  0  0
       0  0  0  0  0  0  0  0  0  0
       0  0 -7  0 -1  1  0  0  0  0
       0  0  0 -1  0  1  1  0  0  0
       0  0  0 -3  0  1 -5  0  0  0
       0  0  0 -1  0  1 -1  0  0  0
       0  0  0  1  0 -3  4  0  0  0
       0  0  0  0  0  0  0  0  0  0
       0  0  0  0  0  0  0  0  0  0];
   
fprintf('Question 1.1:\n')
fprintf('Convolution of the original image with the derivative filter:\n')
fmt = [repmat('%2d ', 1, size(q_1_1,2)-1), '%2d\n'];
fprintf(fmt, q_1_1.'); 
pause

%% Question 1.2
fprintf('\n')
fprintf('Question 1.2:\n')
[Gmag, Gdir] = imgradient(q_1_1);
fprintf('The gradient magnitude at pixel[2,3] is 0\n')
fprintf('The gradient magnitude at pixel[4,3] is 0\n')
fprintf('The gradient magnitude at pixel[4,6] is 1\n')
fprintf('\n')
pause

%% Question 1.3 
fprintf('Question 1.3 starting...\n');
q_1_3
pause;

%% Question 1.4 
fprintf('Question 1.4 starting...\n');
q_1_4
pause;


%% Question 1.5
dimension = 3;
std_deviation = 8;
kernel = fspecial('gaussian',dimension,std_deviation);
img_1 = imread('car.jpg');
img_2=im2double(imread('car.jpg'));
figure (1), imshow(img_1)
tic
imfilter_image1 = imfilter(img_1,kernel);
figure(2), imshow(imfilter_image1)
toc
% 1D Gaussian kernel 
Filter=[3 5];

% 1D Gaussians
X=fspecial('gaussian',[1 Filter(2)]);
Y=fspecial('gaussian',[Filter(1) 1]);
tic
%X-direction
imgX=imfilter(img_2,X);

%Y-direction
imgY=imfilter(imgX,Y); 
toc
fprintf('The tic function records the current time. \n');

pause


%% Question 2
fprintf('Question 2 starting...\n');
q2
pause;

