% Student Name: Vatsal Shreekant
% Student Number: 500771363

%% Least Squares Part 1:
fprintf('Least Squares part 1 starting...\n');
least_squares_1;
fprintf('Least Squares part 1 done! Press enter to continue...\n\n');
pause;
%% Part A: 
fprintf('Part A starting. Please run the vlfeat command.\n');
part_a;
fprintf('Part A done! Press enter to continue...\n\n');
pause;
%% Part B:
fprintf('Part B starting...\n');
part_b;
fprintf('Part B done! Press enter to continue...\n\n');
