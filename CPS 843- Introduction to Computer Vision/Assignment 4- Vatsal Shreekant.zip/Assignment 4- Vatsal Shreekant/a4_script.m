% A4: Optical Flow Estimation
% By: Vatsal Shreekant, student #500771363
%% 1.1: myFlow: Synth Image Set
clc;
clear all;
close all;

win_length=25;
tau=0.01;
synth_0_dir = 'Sequences/Sequences/synth/synth_0.png';
synth_1_dir = 'Sequences/Sequences/synth/synth_1.png';

synth_0=imread(synth_0_dir);
synth_1=imread(synth_1_dir);

synth_0_db = double(synth_0);
synth_0_max = max(synth_0(:));
synth_0_max = double(synth_0_max);

synth_1_db = double(synth_1);
synth_1_max = max(synth_1(:)); 
synth_1_max = double(synth_1_max);

synth_0_norm = synth_0_db;
synth_0_norm = synth_0_norm ./ synth_0_max;
synth_1_norm = synth_1_db;
synth_1_norm = synth_1_norm ./ synth_1_max;
disp("Running myFlow for Synth Image Set");
[u, v, b_map] = myFlow(synth_0_norm,synth_1_norm, win_length,tau);
%% 1.2: flowToColor: Synth Image Set
u = b_map .* u;
v = b_map .* v;
flow_size = size(synth_0_norm);
flow_size_dim_2 = [flow_size,2];
flow=zeros(flow_size_dim_2);
flow(:,:,1) = u;
flow(:,:,2) = v;
disp("Running flowToColor for Synth Image Set");
figure('Name','flowToColor'), imshow(flowToColor(flow),[]);

%% 1.3: myWarp: Synth Image Set
disp("Running myWarp for Synth Image Set");
myWarp(synth_0, synth_1, u, v);



%% 1.1: myFlow: Sphere Image Set
clc;
clear all;
close all;

win_length=25;
tau=0.01;
sphere_0_dir = 'Sequences/Sequences/sphere/sphere_0.png';
sphere_1_dir = 'Sequences/Sequences/sphere/sphere_1.png';

sphere_0=imread(sphere_0_dir);
sphere_0 = rgb2gray(sphere_0);
sphere_1=imread(sphere_1_dir);
sphere_1 = rgb2gray(sphere_1);

sphere_0_db = double(sphere_0);
sphere_0_max = max(sphere_0(:));
sphere_0_max = double(sphere_0_max);

sphere_1_db = double(sphere_1);
sphere_1_max = max(sphere_1(:)); 
sphere_1_max = double(sphere_1_max);

sphere_0_norm = sphere_0_db;
sphere_0_norm = sphere_0_norm ./ sphere_0_max;
sphere_1_norm = sphere_1_db;
sphere_1_norm = sphere_1_norm ./ sphere_1_max;
disp("Running myFlow for Sphere Image Set");
[u, v, b_map] = myFlow(sphere_0_norm,sphere_1_norm, win_length,tau);
%% 1.2: flowToColor: Sphere Image Set

u = b_map .* u;
v = b_map .* v;
flow_size = size(sphere_0_norm);
flow_size_dim_2 = [flow_size,2];
flow=zeros(flow_size_dim_2);
flow(:,:,1) = u;
flow(:,:,2) = v;
disp("Running flowToColor for Sphere Image Set");
figure('Name','flowToColor'), imshow(flowToColor(flow),[]);

%% 1.3: myWarp: Sphere Image Set
disp("Running myWarp for Sphere Image Set");
myWarp(sphere_0, sphere_1, u, v);

%% 1.1: myFlow: Corridor Image Set
clc;
clear all;
close all;

win_length=25;
tau=0.01;

corridor_0_dir = 'Sequences/Sequences/corridor/bt_0.png';
corridor_1_dir = 'Sequences/Sequences/corridor/bt_1.png';

corridor_0=imread(corridor_0_dir);
corridor_1=imread(corridor_1_dir);

corridor_0_db = double(corridor_0);
corridor_0_max = max(corridor_0(:));
corridor_0_max = double(corridor_0_max);

corridor_1_db = double(corridor_1);
corridor_1_max = max(corridor_1(:)); 
corridor_1_max = double(corridor_1_max);

corridor_0_norm = corridor_0_db;
corridor_0_norm = corridor_0_norm ./ corridor_0_max;
corridor_1_norm = corridor_1_db;
corridor_1_norm = corridor_1_norm ./ corridor_1_max;
disp("Running myFlow for Corridor Image Set");
[u, v, b_map] = myFlow(corridor_0_norm,corridor_1_norm, win_length,tau);
%% 1.2: flowToColor: Corridor Image Set

u = b_map .* u;
v = b_map .* v;
flow_size = size(corridor_0_norm);
flow_size_dim_2 = [flow_size,2];
flow=zeros(flow_size_dim_2);
flow(:,:,1) = u;
flow(:,:,2) = v;
disp("Running flowToColor for Corridor Image Set");
figure('Name','flowToColor'), imshow(flowToColor(flow),[]);

%% 1.3: myWarp: Corridor Image Set
disp("Running myWarp for Corridor Image Set");
myWarp(corridor_0, corridor_1, u, v);

