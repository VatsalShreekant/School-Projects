function [u,v,b_map] = myFlow(im_1,im_2, win_length,tau)
im_1_size = size(im_1);
im_2_size = size(im_2);

u = zeros(im_1_size);
v = zeros(im_2_size);
b_map = zeros(im_2_size);
% The five-point derivative of Gaussian convolution filter
gaussian_conv_filter = (1/12)*[-1 8 0 -8 1];
g_conv_filter_x = gaussian_conv_filter;
% Perform a complex conjugate transpose on g_conv_filter_x
g_conv_filter_y = g_conv_filter_x';

%Returns the central part of the convolution, which is the same size as im_1.
I_x_img = conv2(im_1,g_conv_filter_x, 'same');
I_y_img = conv2(im_1,g_conv_filter_y, 'same');

% fspecial: returns a rotationally symmetric Gaussian lowpass filter 
% - The second array is the 3x3 gaussian filter
% - The third parameter is the sigma value of 1
im_1_gaussian = imfilter(im_1,fspecial('gaussian',[3 3],1));
im_2_gaussian = imfilter(im_2,fspecial('gaussian',[3 3],1));
% disp_img_1 = imshow(im_1_gaussian,[]);
% disp_img_2 = imshow(im_2_gaussian,[]);
figure('Name','Image 1'), imshow(im_1_gaussian,[]);
figure('Name','Image 2'), imshow(im_2_gaussian,[]);
imgs_subtracted = im_2_gaussian - im_1_gaussian;
valid_region_matrix = zeros(2,2);
sizing_factor=10;

I_x_img_size_dim1 = size(I_x_img,1);
I_x_img_size_dim1 = I_x_img_size_dim1 - win_length;
win_length_incr_1 = win_length + 1;
I_x_img_size_dim2 = size(I_x_img,2); 
I_x_img_size_dim2 = I_x_img_size_dim2 - win_length; 

for i = win_length_incr_1:I_x_img_size_dim1
    
    for j = win_length_incr_1:I_x_img_size_dim2
        
        win_length_i_decr = i - win_length;
        win_length_i_incr = i + win_length;
        win_length_j_decr = j - win_length;
        win_length_j_incr = j + win_length;        
        i_window_vector = win_length_i_decr:win_length_i_incr;
        j_window_vector = win_length_j_decr:win_length_j_incr; 
        
        spatial_deriv_I_x = I_x_img(i_window_vector, j_window_vector);
        spatial_deriv_I_y = I_y_img(i_window_vector, j_window_vector);
        temporal_deriv_I_t = imgs_subtracted(i_window_vector, j_window_vector);
%       Reshape all elements of temporal_deriv_I_t into a single column vector.
        temporal_deriv_I_t_reshaped = temporal_deriv_I_t(:); 
        temporal_deriv_I_t_reshaped = -(temporal_deriv_I_t_reshaped);

        spatial_deriv_array = [spatial_deriv_I_x(:) spatial_deriv_I_y(:)]; 
%       Moore-Penrose pseudoinverse        
        product_of_Gradients = pinv(spatial_deriv_array);
        product_of_Gradients = product_of_Gradients * temporal_deriv_I_t_reshaped;
        u_val = product_of_Gradients(1); v_val = product_of_Gradients(2);
        u(i,j) = u_val; v(i,j) = v_val;

        valid_region_matrix = transpose(spatial_deriv_array);
        valid_region_matrix = valid_region_matrix * spatial_deriv_array;
%       Returns a column vector containing the eigenvalues of square matrix 'valid_region_matrix'
        e_val=eig(valid_region_matrix);
        e_val_min = min(e_val(1),e_val(2));
        
        if (e_val_min > tau)
            b_map(i,j)=1;
        
        end

    end
end

im_1_size = size(im_1);
[meshgrid_arr_X,meshgrid_arr_Y] = meshgrid(1:im_1_size, 1:im_1_size);
% [meshgrid_arr] = meshgrid(1:im_1_size, 1:im_1_size);
% a = [X, Y, u, v];
% for i= 1:4
%     temp = (1:sizing_factor:end, 1:sizing_factor:end);
%     a(i) = a(i)temp;
% end

x_coord = meshgrid_arr_X(1:sizing_factor:end, 1:sizing_factor:end);
y_coord = meshgrid_arr_Y(1:sizing_factor:end, 1:sizing_factor:end);
u_deci = u(1:sizing_factor:end, 1:sizing_factor:end);
v_deci = v(1:sizing_factor:end, 1:sizing_factor:end);

figure('Name', 'Optical Flow');imshow(im_1);
hold on;
quiver(x_coord, y_coord, u_deci,v_deci, 'b')

end