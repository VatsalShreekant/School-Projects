function myWarp(im_1,im_2,u,v)

X = size(im_2);
Y = size(im_2);
im_1 = im_1;
im_1 = double(im_1);
im_2 = double(im_2);

for i = 1:2
    [x,y] = meshgrid(1:X,1:Y);
end
x_u = x + u;
y_v = y + v;
img_2_warp = interp2(x,y,im_2,x_u,y_v,'cubic');
is_NAN = isnan(img_2_warp);
is_NAN = find(is_NAN);
size_of_isNAN = size(is_NAN);
img_2_warp(is_NAN)=zeros(size_of_isNAN);

img_bicubic = img_2_warp - im_1;
img_bicubic = abs(img_bicubic);
figure('Name','Bicubic');
imshow(img_bicubic);

img_2_warp=interp2(x,y,im_2,x_u,y_v,'linear');
img_2_warp(is_NAN)=zeros(size(is_NAN));
img_bilinear = img_2_warp - im_1;
img_bilinear = abs(img_bilinear);
figure('Name','Bilinear');
imshow(img_bilinear);

for j = 1: 1
for i = 1: 2
    figure('Name','Original');
    imshow(uint8(im_1));
    figure('Name','Warp: Linear');
    imshow(uint8(img_2_warp));
    drawnow;    

disp("Iteration: " + i);

end
disp("The images from the " + i + " iterations have been displayed.");
end



