/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package coe528.lab4;
import java.util.ArrayList;
/**
 *
 * @author vshreeka
 */
public class StackOfDistinctStrings {
    // Overview: StacksOfDistinctStrings are mutable, bounded     
    // collection of distinct strings that operate in  
    // LIFO (Last-In-First-Out) order.  
    // 
    // The abstraction function is:
    // AF(items) = a stack, items, such that
    //  items.isEmpty = null
    //  items.add(element) = items.contains(element)
    //  0 <= i < items.size() && items.contains(element)
    // 
    // The rep invariant is:
    // items.size() > 0 &&
    // items.size() == items.size()-1 &&
    // items.contains(element) is not null
    //  
    // 
    //the rep 
    private ArrayList<String> items; 
    // constructor 
    public StackOfDistinctStrings() { 
        // EFFECTS: Creates a new StackOfDistinctStrings object 
        items = new ArrayList<String>(); 
    } 
    public void push(String element) throws Exception { 
        // MODIFIES: this 
        // EFFECTS: Appends the element at the top of the stack  
        //          if the element is not in the stack, otherwise 
        //          does nothing. 
        if(element == null) {
            throw new Exception();
        } 
        if(false == items.contains(element)) {
            items.add(element);
        } 
    } 
    public String pop() throws Exception { 
        // MODIFIES: this 
        // EFFECTS: Removes an element from the top of the stack  
        if (items.isEmpty()) {
            throw new Exception();
        } 
        return items.remove(items.size()-1); 
    }
    public boolean repOK() {
        // EFFECTS: Returns true if the rep invariant holds for this
        //          object; otherwise returns false
        // c) Write the code for the repOK() here
        for (String item : items) {
            if (item != null)
            
                return true;
            }
        
        if (items.size() == items.size()-1){
            return true;
        }
        return false;
        
        
        
    }
    public String toString() {
        // EFFECTS: Returns a string that contains the strings in the
        //          stack and the top element. Implements the
        //          abstraction function.
        // d) Write the code for the toString() here
        String results = "";
        for(String String: items) {
            results += String;
        }
        return results;
        
    }
}
