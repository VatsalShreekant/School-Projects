/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package coe528.lab3;

/**
 *
 * @author vshreeka
 */
public class Odometer {
    private Counter listOfCounters[];
	private DigitCounter dc;
	private int size;

	public Odometer(int size) {
		this.size = size;
		if (size == 0) {
                throw new IllegalArgumentException("Odometer can't have a size of 0.");
            }
		listOfCounters = new Counter[size];
		dc = new DigitCounter();

		// create objects
		for (int i = 0; i < size; i++) {
			if (i == size - 1) {
				listOfCounters[i] = dc;
				break;
			}
			listOfCounters[i] = new LinkedDigitCounter();
		}
		// set left neighbours
		for (int i = 0; i < size; i++) {
			if (i == size - 1) {
                        break;
                    }
			listOfCounters[i].setLeftNeighbour(listOfCounters[i + 1]);
		}

	}

	public void increment() {
		listOfCounters[0].increment();
	}

	public void decrement() {
		listOfCounters[0].decrement();
	}
	public void reset(){
		for (Counter c:listOfCounters){
			c.reset();
		}
	}
        public String count(){
            for (int i = size - 1; i >= 0; i--) {
			System.out.print(listOfCounters[i].toString());
		}
		return " ";
        }

}
