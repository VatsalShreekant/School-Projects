/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package coe528.lab3;

/**
 *
 * @author vshreeka
 */
public interface Counter {

String count();
//Increment this Counter.
void increment();
//Decrement this Counter.
void decrement();
//Reset this Counter.
void reset();
void setLeftNeighbour(Counter c);
}

