/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package coe528.lab3;

/**
 *
 * @author vshreeka
 */
public class DigitCounter extends AbstractCounter {
    	private int value;

	public DigitCounter() {
		super();
		value = super.getValue();
	}

	@Override
	public void increment() {
		if (value < 9) {
                value++;
            }
		else {
			value = 0;

		}
	}
	
	

	@Override
	public void reset() {
		value=0;
	}

	@Override
	public String toString() {
		return Integer.toString(value);
	}

	@Override
	public void setLeftNeighbour(Counter c) {
		// TODO Auto-generated method stub

}
}
