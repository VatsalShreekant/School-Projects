/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package coe528.lab3;

/**
 *
 * @author vshreeka
 */
public class LinkedDigitCounter extends AbstractCounter {
    private Counter leftNeighbour;
	AbstractCounter ac;

	public LinkedDigitCounter() {
		super();
	}

    @Override
	public void setLeftNeighbour(Counter count) {
		this.leftNeighbour = count;
		ac = (AbstractCounter)leftNeighbour;
	}

	@Override
	public void increment() {
		if (super.getValue() < 9) {
			super.increment();
		} else {
			super.reset();
			leftNeighbour.increment();
		}
	}

	@Override
	public void decrement() {
		
		if (super.getValue()>0){
			super.decrement();
		}else{
			ac.decrement();
			super.setValue(9);
		}
	}

	@Override
	public String toString() {
		return Integer.toString(super.getValue());

}}
