/**
 *  The functions in this module implement a Heapdata structure
 *  of integers.
 */


/**
 * heapDelete() removes the biggest integer in the heap and returns it.
 *
 */

int heapDelete()
{
 int max;
 max = heap[0];
 heap[0] = heap.pop();
heap.pop() = heap.pop()-1;
heapify(0);
 return max;
}

/**
 *  addHeap(thing2add) adds the "thing2add" to the Heap.
 *
 */
void addHeap(int thing2add)
{
heap[last] = thing2add;
i = last;

}

/**
 * heapSize() returns the number of items in the Heap.
 *
 */
int heapSize()
{
  return 0;  //A dummy return statement
}
