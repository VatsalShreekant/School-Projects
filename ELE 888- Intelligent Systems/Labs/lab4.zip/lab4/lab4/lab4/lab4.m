% Nicholas An, 500750378
% Gurvir Parmar, 500765786
% Vatsal Shreekant, 500771363

I = imread('house.tiff');
figure; imshow(I);
[M,N,D]=size(I);
X = reshape(I,M*N, D);
X = double(X);
figure,plot3(X(:,1),X(:,2),X(:,3),'.')
xlim([0 255]);
ylim([0 255]);
zlim([0 255]);
hold on; grid;
title('Pixels in RGB Color');
xlabel('Red');
ylabel('Green');
zlabel('Blue');



%% Part A ---> when cluster value is 2

c=2
disp('Initial Mue Values for Part A');
mue=rand(c,3)*255 % Random numbers between 0 and 255 are initialized
delta_mue = ones(c,3);
iteration = 1;
error_criterion = [];

while(~all(delta_mue(:) == 0))
    
   if iteration == 1
        figure;
        plot3(mue(:,1),mue(:,2),mue(:,3),'*'); % 1st iteration
        title('The First Iteration');
        grid;
   elseif iteration == 2
       figure;
       plot3(mue(:,1),mue(:,2),mue(:,3),'*'); % 2nd iteration
       title('The Second Iteration');
       grid;
   end  
    
   for i = 1:length(X)
       distanceTo1(i,:) = X(i,:) - mue(1,:);
       distanceTo2(i,:) = X(i,:) - mue(2,:); 
       
   end    

    Classification = sum(distanceTo1.^2,2) > sum(distanceTo2.^2,2);
    I = [X Classification];
    Cluster2=I(I(:,4) == 1, 1:3);
    Cluster1=I(I(:,4) ~= 1, 1:3);
    error_criterion_cluster1 = sum(sum((Cluster1 - repmat(mue(1,:),length(Cluster1),1)).^2,2));
    error_criterion_cluster2 = sum(sum((Cluster2 - repmat(mue(2,:),length(Cluster2),1)).^2,2));
    error_criterion(iteration) = error_criterion_cluster1 + error_criterion_cluster2;
    Centroid2 = mean(Cluster2);
    Centroid1 = mean(Cluster1);
    New_Centroids = [Centroid1;Centroid2];
    delta_mue = abs(mue - New_Centroids);
    mue = New_Centroids;
    iteration = iteration + 1;
    
end    
    
     figure;
     plot3(mue(:,1),mue(:,2),mue(:,3),'*'); % The Last Iteration
     title('The Last Iteration');
     grid;
     
     figure;
     plot(error_criterion) % The Last Iteration
     title('Error Criterion')
     xlabel('Iteration')
     ylabel('J')
     grid;
     
    figure;
    plot3(Cluster1(:,1),Cluster1(:,2),Cluster1(:,3),'.','Color', mue(1,:)/255); % Cluster 1
    hold on;
    plot3(Cluster2(:,1),Cluster2(:,2),Cluster2(:,3),'.','Color', mue(2,:)/255); % Cluster 2
    xlim([0 255]);
    ylim([0 255]);
    zlim([0 255]);
    grid;
    title('All the pixels are in RGB');
    xlabel('Red');
    ylabel('Green');
    zlabel('Blue');

    J = ones(length(X),3);
    
    for i = 1 : length(X)
        if Classification(i) == 1
           J(i,:) = mue(2,:);
        else
           J(i,:) = mue(1,:);
        end
    end   

    Ilabeled = reshape(J,M,N,3);
    figure;
    imshow(uint8(Ilabeled));

%% Part B ---> When cluster value is 5 

c=5
disp('Initial Mue Values for Part B');
mue=rand(c,3)*255 % Random numbers between 0 and 255 are initialized 
delta_mue = ones(c,3);
iteration = 1;
classification = zeros(length(X),1);
Error_Criterion = 0;

while(~all(delta_mue(:) == 0))
     
   for i = 1:length(X)
       distanceTo1 = X(i,:) - mue(1,:);
       distanceTo2 = X(i,:) - mue(2,:); 
       distanceTo3 = X(i,:) - mue(3,:); 
       distanceTo4 = X(i,:) - mue(4,:); 
       distanceTo5 = X(i,:) - mue(5,:); 
       distances = [ sum(distanceTo1.^2,2) sum(distanceTo2.^2,2) sum(distanceTo3.^2,2) sum(distanceTo4.^2,2) sum(distanceTo5.^2,2)];
       [row,column] = min(distances);
       classification(i,1) = column;
       
   end    
   
    I = [X classification];
    Cluster1=I(I(:,4) == 1, 1:3);
    Cluster2=I(I(:,4) == 2, 1:3);
    Cluster3=I(I(:,4) == 3, 1:3);
    Cluster4=I(I(:,4) == 4, 1:3);
    Cluster5=I(I(:,4) == 5, 1:3);
    Centroid1 = mean(Cluster1);
    Centroid2 = mean(Cluster2);
    Centroid3 = mean(Cluster3);
    Centroid4 = mean(Cluster4);
    Centroid5 = mean(Cluster5);
    New_Centroids = [Centroid1;Centroid2;Centroid3;Centroid4;Centroid5;];
    delta_mue = abs(mue - New_Centroids);
    mue = New_Centroids;
    iteration = iteration + 1;
    
end    
    
    figure;
    plot3(Cluster1(:,1),Cluster1(:,2),Cluster1(:,3),'.','Color', mue(1,:)/255); % Cluster 1
    hold on;
    plot3(Cluster2(:,1),Cluster2(:,2),Cluster2(:,3),'.','Color', mue(2,:)/255); % Cluster 2
    hold on;
    plot3(Cluster3(:,1),Cluster3(:,2),Cluster3(:,3),'.','Color', mue(3,:)/255); % Cluster 3
    hold on;
    plot3(Cluster4(:,1),Cluster4(:,2),Cluster4(:,3),'.','Color', mue(4,:)/255); % Cluster 4
    hold on;
    plot3(Cluster5(:,1),Cluster5(:,2),Cluster5(:,3),'.','Color', mue(5,:)/255); % Cluster 2
    xlim([0 255]);
    ylim([0 255]);
    zlim([0 255]);
    grid;
    title('All the Pixels are in RGB');
    xlabel('Red');
    ylabel('Green');
    zlabel('Blue');
    
    J = ones(length(X),3);
    
    for i = 1 : length(X)
        if classification(i) == 1
           J(i,:) = mue(1,:);
        elseif classification(i) == 2
           J(i,:) = mue(2,:);
        elseif classification(i) == 3
           J(i,:) = mue(3,:);
        elseif classification(i) == 4
           J(i,:) = mue(4,:);
        elseif classification(i) == 5
           J(i,:) = mue(5,:);
        end
    end   
    

%% Part C ---> Xie-Beni Index (XB)

    XieBeni=0;
    for i=1:size(X)
        for j=1:c
            if I(i,4)==j
                Denominnator = sqrt(sum(((mue-repmat(mue(c,:),c,1)).^2),2));
                Denominnator = sort(Denominnator);
                Denominnator = Denominnator(2);
                XieBeni = XieBeni + ( (norm(I(i,1:3) - mue(j,:)))/Denominnator);
            end
        end
    end

    disp('The Xie-Beni (XB) Index Is');
    XieBeni=XieBeni/length(X)
   
    Ilabeled = reshape(J,M,N,3);
    figure;
    imshow(uint8(Ilabeled));
    
    

